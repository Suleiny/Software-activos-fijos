﻿
namespace Pruebaaa
{
    partial class Propiedad5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Propiedad5));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.datos = new System.Windows.Forms.Label();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2DataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.actualizar = new Guna.UI2.WinForms.Guna2Button();
            this.titule = new Guna.UI2.WinForms.Guna2TextBox();
            this.guardar = new Guna.UI2.WinForms.Guna2Button();
            this.caspropietarios = new Guna.UI2.WinForms.Guna2TextBox();
            this.metro = new Guna.UI2.WinForms.Guna2TextBox();
            this.cafecha = new Guna.UI2.WinForms.Guna2TextBox();
            this.cascantidad = new Guna.UI2.WinForms.Guna2TextBox();
            this.valor2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.valor1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.deuda = new Guna.UI2.WinForms.Guna2TextBox();
            this.casubicacion = new Guna.UI2.WinForms.Guna2TextBox();
            this.catastro = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.guna2Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // datos
            // 
            this.datos.AutoSize = true;
            this.datos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.datos.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.datos.ForeColor = System.Drawing.Color.Cornsilk;
            this.datos.Location = new System.Drawing.Point(4, 382);
            this.datos.Name = "datos";
            this.datos.Size = new System.Drawing.Size(204, 30);
            this.datos.TabIndex = 37;
            this.datos.Text = "Datos Registrados";
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.Location = new System.Drawing.Point(806, 428);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(228, 233);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 36;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.UseTransparentBackground = true;
            // 
            // guna2DataGridView1
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.guna2DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.guna2DataGridView1.BackgroundColor = System.Drawing.Color.Moccasin;
            this.guna2DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.guna2DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.guna2DataGridView1.ColumnHeadersHeight = 4;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView1.DefaultCellStyle = dataGridViewCellStyle6;
            this.guna2DataGridView1.EnableHeadersVisualStyles = false;
            this.guna2DataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.Location = new System.Drawing.Point(2, 415);
            this.guna2DataGridView1.Name = "guna2DataGridView1";
            this.guna2DataGridView1.RowHeadersVisible = false;
            this.guna2DataGridView1.RowHeadersWidth = 51;
            this.guna2DataGridView1.RowTemplate.Height = 24;
            this.guna2DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.guna2DataGridView1.Size = new System.Drawing.Size(798, 274);
            this.guna2DataGridView1.TabIndex = 35;
            this.guna2DataGridView1.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.BackColor = System.Drawing.Color.Moccasin;
            this.guna2DataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Height = 4;
            this.guna2DataGridView1.ThemeStyle.ReadOnly = false;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.guna2DataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Height = 24;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox3.Image")));
            this.guna2PictureBox3.Location = new System.Drawing.Point(3, 83);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(205, 208);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox3.TabIndex = 34;
            this.guna2PictureBox3.TabStop = false;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.AutoScroll = true;
            this.guna2Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.guna2Panel1.BorderColor = System.Drawing.Color.Black;
            this.guna2Panel1.BorderRadius = 25;
            this.guna2Panel1.Controls.Add(this.actualizar);
            this.guna2Panel1.Controls.Add(this.titule);
            this.guna2Panel1.Controls.Add(this.guardar);
            this.guna2Panel1.Controls.Add(this.caspropietarios);
            this.guna2Panel1.Controls.Add(this.metro);
            this.guna2Panel1.Controls.Add(this.cafecha);
            this.guna2Panel1.Controls.Add(this.cascantidad);
            this.guna2Panel1.Controls.Add(this.valor2);
            this.guna2Panel1.Controls.Add(this.valor1);
            this.guna2Panel1.Controls.Add(this.deuda);
            this.guna2Panel1.Controls.Add(this.casubicacion);
            this.guna2Panel1.Controls.Add(this.catastro);
            this.guna2Panel1.CustomBorderColor = System.Drawing.Color.Yellow;
            this.guna2Panel1.Location = new System.Drawing.Point(214, 3);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(820, 406);
            this.guna2Panel1.TabIndex = 33;
            // 
            // actualizar
            // 
            this.actualizar.BackColor = System.Drawing.Color.White;
            this.actualizar.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.actualizar.BorderRadius = 5;
            this.actualizar.BorderThickness = 5;
            this.actualizar.CheckedState.Parent = this.actualizar;
            this.actualizar.CustomImages.Parent = this.actualizar;
            this.actualizar.FillColor = System.Drawing.Color.DodgerBlue;
            this.actualizar.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.actualizar.ForeColor = System.Drawing.Color.Black;
            this.actualizar.HoverState.Parent = this.actualizar;
            this.actualizar.Location = new System.Drawing.Point(592, 329);
            this.actualizar.Name = "actualizar";
            this.actualizar.ShadowDecoration.Parent = this.actualizar;
            this.actualizar.Size = new System.Drawing.Size(180, 45);
            this.actualizar.TabIndex = 16;
            this.actualizar.Text = "Modificar";
            // 
            // titule
            // 
            this.titule.BorderRadius = 5;
            this.titule.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.titule.DefaultText = "";
            this.titule.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.titule.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.titule.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.titule.DisabledState.Parent = this.titule;
            this.titule.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.titule.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.titule.FocusedState.Parent = this.titule;
            this.titule.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titule.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.titule.HoverState.Parent = this.titule;
            this.titule.Location = new System.Drawing.Point(4, 326);
            this.titule.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.titule.Name = "titule";
            this.titule.PasswordChar = '\0';
            this.titule.PlaceholderForeColor = System.Drawing.Color.Black;
            this.titule.PlaceholderText = "Titulo de Propiedad";
            this.titule.SelectedText = "";
            this.titule.ShadowDecoration.Parent = this.titule;
            this.titule.Size = new System.Drawing.Size(256, 48);
            this.titule.TabIndex = 15;
            // 
            // guardar
            // 
            this.guardar.BackColor = System.Drawing.Color.White;
            this.guardar.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.guardar.BorderRadius = 5;
            this.guardar.BorderThickness = 5;
            this.guardar.CheckedState.Parent = this.guardar;
            this.guardar.CustomImages.Parent = this.guardar;
            this.guardar.FillColor = System.Drawing.Color.DodgerBlue;
            this.guardar.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.guardar.ForeColor = System.Drawing.Color.Black;
            this.guardar.HoverState.Parent = this.guardar;
            this.guardar.Location = new System.Drawing.Point(344, 329);
            this.guardar.Name = "guardar";
            this.guardar.ShadowDecoration.Parent = this.guardar;
            this.guardar.Size = new System.Drawing.Size(180, 45);
            this.guardar.TabIndex = 14;
            this.guardar.Text = "Registrar";
            this.guardar.Click += new System.EventHandler(this.guardar_Click);
            // 
            // caspropietarios
            // 
            this.caspropietarios.BorderRadius = 5;
            this.caspropietarios.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.caspropietarios.DefaultText = "";
            this.caspropietarios.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.caspropietarios.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.caspropietarios.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.caspropietarios.DisabledState.Parent = this.caspropietarios;
            this.caspropietarios.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.caspropietarios.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.caspropietarios.FocusedState.Parent = this.caspropietarios;
            this.caspropietarios.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.caspropietarios.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.caspropietarios.HoverState.Parent = this.caspropietarios;
            this.caspropietarios.Location = new System.Drawing.Point(564, 240);
            this.caspropietarios.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caspropietarios.Name = "caspropietarios";
            this.caspropietarios.PasswordChar = '\0';
            this.caspropietarios.PlaceholderForeColor = System.Drawing.Color.Black;
            this.caspropietarios.PlaceholderText = "Propietario";
            this.caspropietarios.SelectedText = "";
            this.caspropietarios.ShadowDecoration.Parent = this.caspropietarios;
            this.caspropietarios.Size = new System.Drawing.Size(256, 48);
            this.caspropietarios.TabIndex = 12;
            // 
            // metro
            // 
            this.metro.BorderRadius = 5;
            this.metro.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.metro.DefaultText = "";
            this.metro.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.metro.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.metro.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.metro.DisabledState.Parent = this.metro;
            this.metro.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.metro.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.metro.FocusedState.Parent = this.metro;
            this.metro.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metro.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.metro.HoverState.Parent = this.metro;
            this.metro.Location = new System.Drawing.Point(286, 44);
            this.metro.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.metro.Name = "metro";
            this.metro.PasswordChar = '\0';
            this.metro.PlaceholderForeColor = System.Drawing.Color.Black;
            this.metro.PlaceholderText = "Metros de la propiedad";
            this.metro.SelectedText = "";
            this.metro.ShadowDecoration.Parent = this.metro;
            this.metro.Size = new System.Drawing.Size(256, 48);
            this.metro.TabIndex = 5;
            // 
            // cafecha
            // 
            this.cafecha.BorderRadius = 5;
            this.cafecha.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.cafecha.DefaultText = "";
            this.cafecha.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.cafecha.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.cafecha.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cafecha.DisabledState.Parent = this.cafecha;
            this.cafecha.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cafecha.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cafecha.FocusedState.Parent = this.cafecha;
            this.cafecha.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cafecha.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cafecha.HoverState.Parent = this.cafecha;
            this.cafecha.Location = new System.Drawing.Point(286, 240);
            this.cafecha.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cafecha.Name = "cafecha";
            this.cafecha.PasswordChar = '\0';
            this.cafecha.PlaceholderForeColor = System.Drawing.Color.Black;
            this.cafecha.PlaceholderText = "Fecha de Ingreso";
            this.cafecha.SelectedText = "";
            this.cafecha.ShadowDecoration.Parent = this.cafecha;
            this.cafecha.Size = new System.Drawing.Size(256, 48);
            this.cafecha.TabIndex = 11;
            // 
            // cascantidad
            // 
            this.cascantidad.BorderRadius = 5;
            this.cascantidad.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.cascantidad.DefaultText = "";
            this.cascantidad.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.cascantidad.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.cascantidad.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cascantidad.DisabledState.Parent = this.cascantidad;
            this.cascantidad.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cascantidad.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cascantidad.FocusedState.Parent = this.cascantidad;
            this.cascantidad.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cascantidad.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cascantidad.HoverState.Parent = this.cascantidad;
            this.cascantidad.Location = new System.Drawing.Point(565, 144);
            this.cascantidad.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cascantidad.Name = "cascantidad";
            this.cascantidad.PasswordChar = '\0';
            this.cascantidad.PlaceholderForeColor = System.Drawing.Color.Black;
            this.cascantidad.PlaceholderText = "Cantidad";
            this.cascantidad.SelectedText = "";
            this.cascantidad.ShadowDecoration.Parent = this.cascantidad;
            this.cascantidad.Size = new System.Drawing.Size(255, 46);
            this.cascantidad.TabIndex = 7;
            // 
            // valor2
            // 
            this.valor2.BorderRadius = 5;
            this.valor2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.valor2.DefaultText = "";
            this.valor2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.valor2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.valor2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.valor2.DisabledState.Parent = this.valor2;
            this.valor2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.valor2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.valor2.FocusedState.Parent = this.valor2;
            this.valor2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valor2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.valor2.HoverState.Parent = this.valor2;
            this.valor2.Location = new System.Drawing.Point(286, 144);
            this.valor2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.valor2.Name = "valor2";
            this.valor2.PasswordChar = '\0';
            this.valor2.PlaceholderForeColor = System.Drawing.Color.Black;
            this.valor2.PlaceholderText = "Valor Actual";
            this.valor2.SelectedText = "";
            this.valor2.ShadowDecoration.Parent = this.valor2;
            this.valor2.Size = new System.Drawing.Size(256, 48);
            this.valor2.TabIndex = 6;
            // 
            // valor1
            // 
            this.valor1.BorderRadius = 5;
            this.valor1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.valor1.DefaultText = "";
            this.valor1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.valor1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.valor1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.valor1.DisabledState.Parent = this.valor1;
            this.valor1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.valor1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.valor1.FocusedState.Parent = this.valor1;
            this.valor1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valor1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.valor1.HoverState.Parent = this.valor1;
            this.valor1.Location = new System.Drawing.Point(0, 146);
            this.valor1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.valor1.Name = "valor1";
            this.valor1.PasswordChar = '\0';
            this.valor1.PlaceholderForeColor = System.Drawing.Color.Black;
            this.valor1.PlaceholderText = "Valor  Inicial";
            this.valor1.SelectedText = "";
            this.valor1.ShadowDecoration.Parent = this.valor1;
            this.valor1.Size = new System.Drawing.Size(255, 46);
            this.valor1.TabIndex = 4;
            this.valor1.TextChanged += new System.EventHandler(this.valor1_TextChanged);
            // 
            // deuda
            // 
            this.deuda.BorderRadius = 5;
            this.deuda.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.deuda.DefaultText = "";
            this.deuda.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.deuda.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.deuda.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.deuda.DisabledState.Parent = this.deuda;
            this.deuda.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.deuda.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.deuda.FocusedState.Parent = this.deuda;
            this.deuda.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deuda.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.deuda.HoverState.Parent = this.deuda;
            this.deuda.Location = new System.Drawing.Point(4, 240);
            this.deuda.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.deuda.Name = "deuda";
            this.deuda.PasswordChar = '\0';
            this.deuda.PlaceholderForeColor = System.Drawing.Color.Black;
            this.deuda.PlaceholderText = "Deuda";
            this.deuda.SelectedText = "";
            this.deuda.ShadowDecoration.Parent = this.deuda;
            this.deuda.Size = new System.Drawing.Size(256, 48);
            this.deuda.TabIndex = 3;
            // 
            // casubicacion
            // 
            this.casubicacion.BorderRadius = 5;
            this.casubicacion.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.casubicacion.DefaultText = "";
            this.casubicacion.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.casubicacion.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.casubicacion.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.casubicacion.DisabledState.Parent = this.casubicacion;
            this.casubicacion.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.casubicacion.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.casubicacion.FocusedState.Parent = this.casubicacion;
            this.casubicacion.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.casubicacion.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.casubicacion.HoverState.Parent = this.casubicacion;
            this.casubicacion.Location = new System.Drawing.Point(564, 44);
            this.casubicacion.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.casubicacion.Name = "casubicacion";
            this.casubicacion.PasswordChar = '\0';
            this.casubicacion.PlaceholderForeColor = System.Drawing.Color.Black;
            this.casubicacion.PlaceholderText = "Ubicacion";
            this.casubicacion.SelectedText = "";
            this.casubicacion.ShadowDecoration.Parent = this.casubicacion;
            this.casubicacion.Size = new System.Drawing.Size(256, 48);
            this.casubicacion.TabIndex = 2;
            // 
            // catastro
            // 
            this.catastro.BorderRadius = 5;
            this.catastro.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.catastro.DefaultText = "";
            this.catastro.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.catastro.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.catastro.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.catastro.DisabledState.Parent = this.catastro;
            this.catastro.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.catastro.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.catastro.FocusedState.Parent = this.catastro;
            this.catastro.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.catastro.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.catastro.HoverState.Parent = this.catastro;
            this.catastro.Location = new System.Drawing.Point(0, 46);
            this.catastro.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.catastro.Name = "catastro";
            this.catastro.PasswordChar = '\0';
            this.catastro.PlaceholderForeColor = System.Drawing.Color.Black;
            this.catastro.PlaceholderText = "Catastro";
            this.catastro.SelectedText = "";
            this.catastro.ShadowDecoration.Parent = this.catastro;
            this.catastro.Size = new System.Drawing.Size(255, 46);
            this.catastro.TabIndex = 1;
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.CheckedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.Location = new System.Drawing.Point(3, 12);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.PressedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Size = new System.Drawing.Size(66, 65);
            this.guna2ImageButton3.TabIndex = 43;
            this.guna2ImageButton3.Click += new System.EventHandler(this.guna2ImageButton3_Click);
            // 
            // Propiedad5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.ClientSize = new System.Drawing.Size(1035, 692);
            this.Controls.Add(this.guna2ImageButton3);
            this.Controls.Add(this.datos);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.guna2DataGridView1);
            this.Controls.Add(this.guna2PictureBox3);
            this.Controls.Add(this.guna2Panel1);
            this.Name = "Propiedad5";
            this.Text = "Propiedad5";
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.guna2Panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label datos;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2TextBox caspropietarios;
        private Guna.UI2.WinForms.Guna2TextBox cafecha;
        private Guna.UI2.WinForms.Guna2TextBox cascantidad;
        private Guna.UI2.WinForms.Guna2TextBox valor2;
        private Guna.UI2.WinForms.Guna2TextBox valor1;
        private Guna.UI2.WinForms.Guna2TextBox deuda;
        private Guna.UI2.WinForms.Guna2TextBox catastro;
        private Guna.UI2.WinForms.Guna2Button guardar;
        private Guna.UI2.WinForms.Guna2TextBox metro;
        private Guna.UI2.WinForms.Guna2TextBox casubicacion;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
        private Guna.UI2.WinForms.Guna2TextBox titule;
        private Guna.UI2.WinForms.Guna2Button actualizar;
    }
}