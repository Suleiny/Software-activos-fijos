﻿
namespace Pruebaaa
{
    partial class User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(User));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.datos = new System.Windows.Forms.Label();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2ImageButton4 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton2 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton1 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.academico = new Guna.UI2.WinForms.Guna2TextBox();
            this.empltelf2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.sexo = new Guna.UI2.WinForms.Guna2TextBox();
            this.ocupacion = new Guna.UI2.WinForms.Guna2TextBox();
            this.estad = new Guna.UI2.WinForms.Guna2TextBox();
            this.empldireccion = new Guna.UI2.WinForms.Guna2TextBox();
            this.emptelef = new Guna.UI2.WinForms.Guna2TextBox();
            this.empGmail = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2TextBox3 = new Guna.UI2.WinForms.Guna2TextBox();
            this.EmpCedula = new Guna.UI2.WinForms.Guna2TextBox();
            this.empapellido = new Guna.UI2.WinForms.Guna2TextBox();
            this.empnombre = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.BUSCUSER = new Guna.UI2.WinForms.Guna2TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.error = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.error)).BeginInit();
            this.SuspendLayout();
            // 
            // datos
            // 
            this.datos.AutoSize = true;
            this.datos.BackColor = System.Drawing.Color.Black;
            this.datos.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.datos.ForeColor = System.Drawing.Color.Cornsilk;
            this.datos.Location = new System.Drawing.Point(26, 751);
            this.datos.Name = "datos";
            this.datos.Size = new System.Drawing.Size(204, 30);
            this.datos.TabIndex = 28;
            this.datos.Text = "Datos Registrados";
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox3.Image")));
            this.guna2PictureBox3.Location = new System.Drawing.Point(910, 142);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(197, 214);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox3.TabIndex = 29;
            this.guna2PictureBox3.TabStop = false;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(141)))), ((int)(((byte)(117)))));
            this.guna2Panel1.BorderRadius = 20;
            this.guna2Panel1.Controls.Add(this.guna2ImageButton4);
            this.guna2Panel1.Controls.Add(this.guna2ImageButton2);
            this.guna2Panel1.Controls.Add(this.guna2ImageButton1);
            this.guna2Panel1.Controls.Add(this.guna2ImageButton3);
            this.guna2Panel1.Controls.Add(this.academico);
            this.guna2Panel1.Controls.Add(this.empltelf2);
            this.guna2Panel1.Controls.Add(this.sexo);
            this.guna2Panel1.Controls.Add(this.ocupacion);
            this.guna2Panel1.Controls.Add(this.estad);
            this.guna2Panel1.Controls.Add(this.empldireccion);
            this.guna2Panel1.Controls.Add(this.emptelef);
            this.guna2Panel1.Controls.Add(this.empGmail);
            this.guna2Panel1.Controls.Add(this.guna2TextBox3);
            this.guna2Panel1.Controls.Add(this.EmpCedula);
            this.guna2Panel1.Controls.Add(this.empapellido);
            this.guna2Panel1.Controls.Add(this.empnombre);
            this.guna2Panel1.Location = new System.Drawing.Point(0, 4);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(904, 398);
            this.guna2Panel1.TabIndex = 27;
            // 
            // guna2ImageButton4
            // 
            this.guna2ImageButton4.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.CheckedState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.HoverState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton4.Image")));
            this.guna2ImageButton4.ImageRotate = 0F;
            this.guna2ImageButton4.Location = new System.Drawing.Point(826, 51);
            this.guna2ImageButton4.Name = "guna2ImageButton4";
            this.guna2ImageButton4.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.PressedState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.Size = new System.Drawing.Size(68, 73);
            this.guna2ImageButton4.TabIndex = 43;
            this.guna2ImageButton4.Click += new System.EventHandler(this.guna2ImageButton4_Click);
            // 
            // guna2ImageButton2
            // 
            this.guna2ImageButton2.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.CheckedState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.HoverState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton2.Image")));
            this.guna2ImageButton2.ImageRotate = 0F;
            this.guna2ImageButton2.Location = new System.Drawing.Point(826, 275);
            this.guna2ImageButton2.Name = "guna2ImageButton2";
            this.guna2ImageButton2.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.PressedState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.Size = new System.Drawing.Size(68, 73);
            this.guna2ImageButton2.TabIndex = 41;
            this.guna2ImageButton2.Click += new System.EventHandler(this.guna2ImageButton2_Click);
            // 
            // guna2ImageButton1
            // 
            this.guna2ImageButton1.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.CheckedState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.HoverState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton1.Image")));
            this.guna2ImageButton1.ImageRotate = 0F;
            this.guna2ImageButton1.Location = new System.Drawing.Point(826, 156);
            this.guna2ImageButton1.Name = "guna2ImageButton1";
            this.guna2ImageButton1.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.PressedState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.Size = new System.Drawing.Size(68, 73);
            this.guna2ImageButton1.TabIndex = 42;
            this.guna2ImageButton1.Click += new System.EventHandler(this.guna2ImageButton1_Click);
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.CheckedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.Location = new System.Drawing.Point(0, 0);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.PressedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Size = new System.Drawing.Size(49, 48);
            this.guna2ImageButton3.TabIndex = 43;
            this.guna2ImageButton3.Click += new System.EventHandler(this.guna2ImageButton3_Click);
            // 
            // academico
            // 
            this.academico.BorderRadius = 5;
            this.academico.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.academico.DefaultText = "";
            this.academico.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.academico.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.academico.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.academico.DisabledState.Parent = this.academico;
            this.academico.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.academico.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.academico.FocusedState.Parent = this.academico;
            this.academico.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.academico.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.academico.HoverState.Parent = this.academico;
            this.academico.Location = new System.Drawing.Point(299, 304);
            this.academico.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.academico.Name = "academico";
            this.academico.PasswordChar = '\0';
            this.academico.PlaceholderForeColor = System.Drawing.Color.Black;
            this.academico.PlaceholderText = "Nivel academico";
            this.academico.SelectedText = "";
            this.academico.ShadowDecoration.Parent = this.academico;
            this.academico.Size = new System.Drawing.Size(256, 48);
            this.academico.TabIndex = 12;
            this.academico.Validated += new System.EventHandler(this.academico_Validated);
            // 
            // empltelf2
            // 
            this.empltelf2.BorderRadius = 5;
            this.empltelf2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.empltelf2.DefaultText = "";
            this.empltelf2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.empltelf2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.empltelf2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.empltelf2.DisabledState.Parent = this.empltelf2;
            this.empltelf2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.empltelf2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.empltelf2.FocusedState.Parent = this.empltelf2;
            this.empltelf2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empltelf2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.empltelf2.HoverState.Parent = this.empltelf2;
            this.empltelf2.Location = new System.Drawing.Point(294, 233);
            this.empltelf2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.empltelf2.Name = "empltelf2";
            this.empltelf2.PasswordChar = '\0';
            this.empltelf2.PlaceholderForeColor = System.Drawing.Color.Black;
            this.empltelf2.PlaceholderText = "Telefono";
            this.empltelf2.SelectedText = "";
            this.empltelf2.ShadowDecoration.Parent = this.empltelf2;
            this.empltelf2.Size = new System.Drawing.Size(256, 48);
            this.empltelf2.TabIndex = 9;
            this.empltelf2.Validated += new System.EventHandler(this.empltelf2_Validated);
            // 
            // sexo
            // 
            this.sexo.BorderRadius = 5;
            this.sexo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.sexo.DefaultText = "";
            this.sexo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.sexo.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.sexo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.sexo.DisabledState.Parent = this.sexo;
            this.sexo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.sexo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.sexo.FocusedState.Parent = this.sexo;
            this.sexo.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sexo.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.sexo.HoverState.Parent = this.sexo;
            this.sexo.Location = new System.Drawing.Point(12, 144);
            this.sexo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.sexo.Name = "sexo";
            this.sexo.PasswordChar = '\0';
            this.sexo.PlaceholderForeColor = System.Drawing.Color.Black;
            this.sexo.PlaceholderText = "Sexo";
            this.sexo.SelectedText = "";
            this.sexo.ShadowDecoration.Parent = this.sexo;
            this.sexo.Size = new System.Drawing.Size(256, 48);
            this.sexo.TabIndex = 5;
            this.sexo.Validated += new System.EventHandler(this.sexo_Validated);
            // 
            // ocupacion
            // 
            this.ocupacion.BorderRadius = 5;
            this.ocupacion.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ocupacion.DefaultText = "";
            this.ocupacion.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ocupacion.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ocupacion.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ocupacion.DisabledState.Parent = this.ocupacion;
            this.ocupacion.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ocupacion.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ocupacion.FocusedState.Parent = this.ocupacion;
            this.ocupacion.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ocupacion.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ocupacion.HoverState.Parent = this.ocupacion;
            this.ocupacion.Location = new System.Drawing.Point(563, 306);
            this.ocupacion.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ocupacion.Name = "ocupacion";
            this.ocupacion.PasswordChar = '\0';
            this.ocupacion.PlaceholderForeColor = System.Drawing.Color.Black;
            this.ocupacion.PlaceholderText = "Ocupacion";
            this.ocupacion.SelectedText = "";
            this.ocupacion.ShadowDecoration.Parent = this.ocupacion;
            this.ocupacion.Size = new System.Drawing.Size(256, 48);
            this.ocupacion.TabIndex = 11;
            this.ocupacion.Validated += new System.EventHandler(this.ocupacion_Validated);
            // 
            // estad
            // 
            this.estad.BorderRadius = 5;
            this.estad.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.estad.DefaultText = "";
            this.estad.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.estad.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.estad.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.estad.DisabledState.Parent = this.estad;
            this.estad.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.estad.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.estad.FocusedState.Parent = this.estad;
            this.estad.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.estad.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.estad.HoverState.Parent = this.estad;
            this.estad.Location = new System.Drawing.Point(13, 302);
            this.estad.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.estad.Name = "estad";
            this.estad.PasswordChar = '\0';
            this.estad.PlaceholderForeColor = System.Drawing.Color.Black;
            this.estad.PlaceholderText = "Estado civil";
            this.estad.SelectedText = "";
            this.estad.ShadowDecoration.Parent = this.estad;
            this.estad.Size = new System.Drawing.Size(255, 46);
            this.estad.TabIndex = 10;
            this.estad.Validated += new System.EventHandler(this.estad_Validated);
            // 
            // empldireccion
            // 
            this.empldireccion.BorderRadius = 5;
            this.empldireccion.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.empldireccion.DefaultText = "";
            this.empldireccion.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.empldireccion.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.empldireccion.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.empldireccion.DisabledState.Parent = this.empldireccion;
            this.empldireccion.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.empldireccion.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.empldireccion.FocusedState.Parent = this.empldireccion;
            this.empldireccion.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empldireccion.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.empldireccion.HoverState.Parent = this.empldireccion;
            this.empldireccion.Location = new System.Drawing.Point(563, 231);
            this.empldireccion.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.empldireccion.Name = "empldireccion";
            this.empldireccion.PasswordChar = '\0';
            this.empldireccion.PlaceholderForeColor = System.Drawing.Color.Black;
            this.empldireccion.PlaceholderText = "Direccion";
            this.empldireccion.SelectedText = "";
            this.empldireccion.ShadowDecoration.Parent = this.empldireccion;
            this.empldireccion.Size = new System.Drawing.Size(256, 48);
            this.empldireccion.TabIndex = 8;
            this.empldireccion.Validated += new System.EventHandler(this.empldireccion_Validated);
            // 
            // emptelef
            // 
            this.emptelef.BorderRadius = 5;
            this.emptelef.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.emptelef.DefaultText = "";
            this.emptelef.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.emptelef.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.emptelef.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.emptelef.DisabledState.Parent = this.emptelef;
            this.emptelef.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.emptelef.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.emptelef.FocusedState.Parent = this.emptelef;
            this.emptelef.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emptelef.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.emptelef.HoverState.Parent = this.emptelef;
            this.emptelef.Location = new System.Drawing.Point(13, 231);
            this.emptelef.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.emptelef.Name = "emptelef";
            this.emptelef.PasswordChar = '\0';
            this.emptelef.PlaceholderForeColor = System.Drawing.Color.Black;
            this.emptelef.PlaceholderText = "Celular";
            this.emptelef.SelectedText = "";
            this.emptelef.ShadowDecoration.Parent = this.emptelef;
            this.emptelef.Size = new System.Drawing.Size(255, 46);
            this.emptelef.TabIndex = 7;
            this.emptelef.Validated += new System.EventHandler(this.emptelef_Validated);
            // 
            // empGmail
            // 
            this.empGmail.BorderRadius = 5;
            this.empGmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.empGmail.DefaultText = "";
            this.empGmail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.empGmail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.empGmail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.empGmail.DisabledState.Parent = this.empGmail;
            this.empGmail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.empGmail.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.empGmail.FocusedState.Parent = this.empGmail;
            this.empGmail.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empGmail.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.empGmail.HoverState.Parent = this.empGmail;
            this.empGmail.Location = new System.Drawing.Point(563, 144);
            this.empGmail.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.empGmail.Name = "empGmail";
            this.empGmail.PasswordChar = '\0';
            this.empGmail.PlaceholderForeColor = System.Drawing.Color.Black;
            this.empGmail.PlaceholderText = "Correo";
            this.empGmail.SelectedText = "";
            this.empGmail.ShadowDecoration.Parent = this.empGmail;
            this.empGmail.Size = new System.Drawing.Size(256, 48);
            this.empGmail.TabIndex = 6;
            this.empGmail.Validated += new System.EventHandler(this.empGmail_Validated);
            // 
            // guna2TextBox3
            // 
            this.guna2TextBox3.BorderRadius = 5;
            this.guna2TextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox3.DefaultText = "";
            this.guna2TextBox3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3.DisabledState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.FocusedState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox3.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.HoverState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.Location = new System.Drawing.Point(295, 146);
            this.guna2TextBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.guna2TextBox3.Name = "guna2TextBox3";
            this.guna2TextBox3.PasswordChar = '\0';
            this.guna2TextBox3.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox3.PlaceholderText = "Fecha Nacimiento";
            this.guna2TextBox3.SelectedText = "";
            this.guna2TextBox3.ShadowDecoration.Parent = this.guna2TextBox3;
            this.guna2TextBox3.Size = new System.Drawing.Size(255, 46);
            this.guna2TextBox3.TabIndex = 4;
            this.guna2TextBox3.TextChanged += new System.EventHandler(this.guna2TextBox3_TextChanged);
            this.guna2TextBox3.Validated += new System.EventHandler(this.guna2TextBox3_Validated);
            // 
            // EmpCedula
            // 
            this.EmpCedula.BorderRadius = 5;
            this.EmpCedula.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.EmpCedula.DefaultText = "";
            this.EmpCedula.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.EmpCedula.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.EmpCedula.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.EmpCedula.DisabledState.Parent = this.EmpCedula;
            this.EmpCedula.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.EmpCedula.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.EmpCedula.FocusedState.Parent = this.EmpCedula;
            this.EmpCedula.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpCedula.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.EmpCedula.HoverState.Parent = this.EmpCedula;
            this.EmpCedula.Location = new System.Drawing.Point(563, 51);
            this.EmpCedula.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.EmpCedula.Name = "EmpCedula";
            this.EmpCedula.PasswordChar = '\0';
            this.EmpCedula.PlaceholderForeColor = System.Drawing.Color.Black;
            this.EmpCedula.PlaceholderText = "Cedula";
            this.EmpCedula.SelectedText = "";
            this.EmpCedula.ShadowDecoration.Parent = this.EmpCedula;
            this.EmpCedula.Size = new System.Drawing.Size(256, 48);
            this.EmpCedula.TabIndex = 3;
            this.EmpCedula.Validated += new System.EventHandler(this.EmpCedula_Validated);
            // 
            // empapellido
            // 
            this.empapellido.BorderRadius = 5;
            this.empapellido.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.empapellido.DefaultText = "";
            this.empapellido.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.empapellido.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.empapellido.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.empapellido.DisabledState.Parent = this.empapellido;
            this.empapellido.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.empapellido.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.empapellido.FocusedState.Parent = this.empapellido;
            this.empapellido.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empapellido.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.empapellido.HoverState.Parent = this.empapellido;
            this.empapellido.Location = new System.Drawing.Point(294, 51);
            this.empapellido.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.empapellido.Name = "empapellido";
            this.empapellido.PasswordChar = '\0';
            this.empapellido.PlaceholderForeColor = System.Drawing.Color.Black;
            this.empapellido.PlaceholderText = "Apellido";
            this.empapellido.SelectedText = "";
            this.empapellido.ShadowDecoration.Parent = this.empapellido;
            this.empapellido.Size = new System.Drawing.Size(256, 48);
            this.empapellido.TabIndex = 2;
            this.empapellido.Validated += new System.EventHandler(this.empapellido_Validated);
            // 
            // empnombre
            // 
            this.empnombre.BorderRadius = 5;
            this.empnombre.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.empnombre.DefaultText = "";
            this.empnombre.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.empnombre.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.empnombre.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.empnombre.DisabledState.Parent = this.empnombre;
            this.empnombre.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.empnombre.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.empnombre.FocusedState.Parent = this.empnombre;
            this.empnombre.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empnombre.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.empnombre.HoverState.Parent = this.empnombre;
            this.empnombre.Location = new System.Drawing.Point(13, 54);
            this.empnombre.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.empnombre.Name = "empnombre";
            this.empnombre.PasswordChar = '\0';
            this.empnombre.PlaceholderForeColor = System.Drawing.Color.Black;
            this.empnombre.PlaceholderText = "Nombre";
            this.empnombre.SelectedText = "";
            this.empnombre.ShadowDecoration.Parent = this.empnombre;
            this.empnombre.Size = new System.Drawing.Size(255, 46);
            this.empnombre.TabIndex = 1;
            this.empnombre.Validated += new System.EventHandler(this.empnombre_Validated);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.Location = new System.Drawing.Point(2, 494);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(228, 233);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 37;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.UseTransparentBackground = true;
            // 
            // BUSCUSER
            // 
            this.BUSCUSER.BorderRadius = 5;
            this.BUSCUSER.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BUSCUSER.DefaultText = "";
            this.BUSCUSER.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BUSCUSER.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BUSCUSER.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BUSCUSER.DisabledState.Parent = this.BUSCUSER;
            this.BUSCUSER.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BUSCUSER.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BUSCUSER.FocusedState.Parent = this.BUSCUSER;
            this.BUSCUSER.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUSCUSER.ForeColor = System.Drawing.Color.Black;
            this.BUSCUSER.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BUSCUSER.HoverState.Parent = this.BUSCUSER;
            this.BUSCUSER.Location = new System.Drawing.Point(372, 442);
            this.BUSCUSER.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BUSCUSER.Name = "BUSCUSER";
            this.BUSCUSER.PasswordChar = '\0';
            this.BUSCUSER.PlaceholderText = "Ingresar Busquedad";
            this.BUSCUSER.SelectedText = "";
            this.BUSCUSER.ShadowDecoration.Parent = this.BUSCUSER;
            this.BUSCUSER.Size = new System.Drawing.Size(580, 46);
            this.BUSCUSER.TabIndex = 38;
            this.BUSCUSER.TextChanged += new System.EventHandler(this.BUSCUSER_TextChanged);
            this.BUSCUSER.KeyUp += new System.Windows.Forms.KeyEventHandler(this.BUSCUSER_KeyUp);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 7.8F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Teal;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(77)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.Location = new System.Drawing.Point(236, 494);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(77)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(871, 306);
            this.dataGridView1.TabIndex = 40;
            // 
            // error
            // 
            this.error.ContainerControl = this;
            // 
            // User
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(141)))), ((int)(((byte)(117)))));
            this.ClientSize = new System.Drawing.Size(1112, 803);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.BUSCUSER);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.datos);
            this.Controls.Add(this.guna2PictureBox3);
            this.Controls.Add(this.guna2Panel1);
            this.Name = "User";
            this.Load += new System.EventHandler(this.User_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.guna2Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.error)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label datos;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2TextBox academico;
        private Guna.UI2.WinForms.Guna2TextBox empltelf2;
        private Guna.UI2.WinForms.Guna2TextBox sexo;
        private Guna.UI2.WinForms.Guna2TextBox ocupacion;
        private Guna.UI2.WinForms.Guna2TextBox estad;
        private Guna.UI2.WinForms.Guna2TextBox empldireccion;
        private Guna.UI2.WinForms.Guna2TextBox emptelef;
        private Guna.UI2.WinForms.Guna2TextBox empGmail;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox3;
        private Guna.UI2.WinForms.Guna2TextBox EmpCedula;
        private Guna.UI2.WinForms.Guna2TextBox empapellido;
        private Guna.UI2.WinForms.Guna2TextBox empnombre;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
        private Guna.UI2.WinForms.Guna2TextBox BUSCUSER;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton2;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton1;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton4;
        private System.Windows.Forms.ErrorProvider error;
    }
}