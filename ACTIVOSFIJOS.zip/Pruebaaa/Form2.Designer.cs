﻿
namespace Pruebaaa
{
    partial class Formbienveida
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Formbienveida));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.usuanombre = new System.Windows.Forms.Label();
            this.btnusuario = new Guna.UI2.WinForms.Guna2Button();
            this.btnayuda = new Guna.UI2.WinForms.Guna2Button();
            this.btnreportes = new Guna.UI2.WinForms.Guna2Button();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.btnintres = new Guna.UI2.WinForms.Guna2Button();
            this.btnempleado = new Guna.UI2.WinForms.Guna2Button();
            this.btnbuscar = new Guna.UI2.WinForms.Guna2Button();
            this.btnactivos = new Guna.UI2.WinForms.Guna2Button();
            this.btnhome = new Guna.UI2.WinForms.Guna2Button();
            this.bienvenida = new System.Windows.Forms.Label();
            this.labnombE = new System.Windows.Forms.Label();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.hola = new System.Windows.Forms.Label();
            this.gunaCirclePictureBox5 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaCirclePictureBox4 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaCirclePictureBox3 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaCirclePictureBox2 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaCirclePictureBox1 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.guna2CirclePictureBox4 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.guna2CirclePictureBox3 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.guna2CirclePictureBox6 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.facebook = new System.Windows.Forms.Label();
            this.guna2CirclePictureBox2 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.guna2CirclePictureBox5 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.telefono = new System.Windows.Forms.Label();
            this.Lemail = new System.Windows.Forms.Label();
            this.ubicacion = new System.Windows.Forms.Label();
            this.instagram = new System.Windows.Forms.Label();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2CirclePictureBox7 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.lbhora = new System.Windows.Forms.Label();
            this.lbfecha = new System.Windows.Forms.Label();
            this.tiempo = new System.Windows.Forms.Timer(this.components);
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            this.guna2Panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox5)).BeginInit();
            this.guna2Panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(79)))), ((int)(((byte)(114)))));
            this.guna2Panel1.Controls.Add(this.usuanombre);
            this.guna2Panel1.Controls.Add(this.btnusuario);
            this.guna2Panel1.Controls.Add(this.btnayuda);
            this.guna2Panel1.Controls.Add(this.btnreportes);
            this.guna2Panel1.Controls.Add(this.guna2CirclePictureBox1);
            this.guna2Panel1.Controls.Add(this.btnintres);
            this.guna2Panel1.Controls.Add(this.btnempleado);
            this.guna2Panel1.Controls.Add(this.btnbuscar);
            this.guna2Panel1.Controls.Add(this.btnactivos);
            this.guna2Panel1.Controls.Add(this.btnhome);
            this.guna2Panel1.Location = new System.Drawing.Point(1, 2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(234, 743);
            this.guna2Panel1.TabIndex = 0;
            this.guna2Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2Panel1_Paint);
            // 
            // usuanombre
            // 
            this.usuanombre.AutoSize = true;
            this.usuanombre.Location = new System.Drawing.Point(83, 156);
            this.usuanombre.Name = "usuanombre";
            this.usuanombre.Size = new System.Drawing.Size(46, 17);
            this.usuanombre.TabIndex = 15;
            this.usuanombre.Text = "label5";
            // 
            // btnusuario
            // 
            this.btnusuario.BorderRadius = 5;
            this.btnusuario.CheckedState.Parent = this.btnusuario;
            this.btnusuario.CustomImages.Parent = this.btnusuario;
            this.btnusuario.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnusuario.ForeColor = System.Drawing.Color.White;
            this.btnusuario.HoverState.Parent = this.btnusuario;
            this.btnusuario.Image = ((System.Drawing.Image)(resources.GetObject("btnusuario.Image")));
            this.btnusuario.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnusuario.ImageSize = new System.Drawing.Size(45, 45);
            this.btnusuario.Location = new System.Drawing.Point(0, 343);
            this.btnusuario.Name = "btnusuario";
            this.btnusuario.ShadowDecoration.Parent = this.btnusuario;
            this.btnusuario.Size = new System.Drawing.Size(219, 50);
            this.btnusuario.TabIndex = 13;
            this.btnusuario.Text = "Usuarios";
            this.btnusuario.Click += new System.EventHandler(this.Usuarios_Click);
            // 
            // btnayuda
            // 
            this.btnayuda.BorderRadius = 5;
            this.btnayuda.CheckedState.Parent = this.btnayuda;
            this.btnayuda.CustomImages.Parent = this.btnayuda;
            this.btnayuda.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnayuda.ForeColor = System.Drawing.Color.White;
            this.btnayuda.HoverState.Parent = this.btnayuda;
            this.btnayuda.Image = ((System.Drawing.Image)(resources.GetObject("btnayuda.Image")));
            this.btnayuda.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnayuda.ImageSize = new System.Drawing.Size(45, 45);
            this.btnayuda.Location = new System.Drawing.Point(3, 675);
            this.btnayuda.Name = "btnayuda";
            this.btnayuda.ShadowDecoration.Parent = this.btnayuda;
            this.btnayuda.Size = new System.Drawing.Size(219, 50);
            this.btnayuda.TabIndex = 12;
            this.btnayuda.Text = "Ayuda";
            this.btnayuda.Click += new System.EventHandler(this.botn7_Click);
            // 
            // btnreportes
            // 
            this.btnreportes.BorderRadius = 5;
            this.btnreportes.CheckedState.Parent = this.btnreportes;
            this.btnreportes.CustomImages.Parent = this.btnreportes;
            this.btnreportes.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnreportes.ForeColor = System.Drawing.Color.White;
            this.btnreportes.HoverState.Parent = this.btnreportes;
            this.btnreportes.Image = ((System.Drawing.Image)(resources.GetObject("btnreportes.Image")));
            this.btnreportes.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnreportes.ImageSize = new System.Drawing.Size(45, 45);
            this.btnreportes.Location = new System.Drawing.Point(3, 542);
            this.btnreportes.Name = "btnreportes";
            this.btnreportes.ShadowDecoration.Parent = this.btnreportes;
            this.btnreportes.Size = new System.Drawing.Size(219, 50);
            this.btnreportes.TabIndex = 7;
            this.btnreportes.Text = "Reportes";
            this.btnreportes.Click += new System.EventHandler(this.boton6_Click);
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(79)))), ((int)(((byte)(114)))));
            this.guna2CirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox1.Image")));
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(40, 3);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.ShadowDecoration.Parent = this.guna2CirclePictureBox1;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(143, 139);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox1.TabIndex = 3;
            this.guna2CirclePictureBox1.TabStop = false;
            // 
            // btnintres
            // 
            this.btnintres.BorderRadius = 5;
            this.btnintres.CheckedState.Parent = this.btnintres;
            this.btnintres.CustomImages.Parent = this.btnintres;
            this.btnintres.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnintres.ForeColor = System.Drawing.Color.White;
            this.btnintres.HoverState.Parent = this.btnintres;
            this.btnintres.Image = ((System.Drawing.Image)(resources.GetObject("btnintres.Image")));
            this.btnintres.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnintres.ImageSize = new System.Drawing.Size(45, 45);
            this.btnintres.Location = new System.Drawing.Point(3, 609);
            this.btnintres.Name = "btnintres";
            this.btnintres.ShadowDecoration.Parent = this.btnintres;
            this.btnintres.Size = new System.Drawing.Size(219, 50);
            this.btnintres.TabIndex = 6;
            this.btnintres.Text = "Interes";
            this.btnintres.Click += new System.EventHandler(this.boton5_Click);
            // 
            // btnempleado
            // 
            this.btnempleado.BorderRadius = 5;
            this.btnempleado.CheckedState.Parent = this.btnempleado;
            this.btnempleado.CustomImages.Parent = this.btnempleado;
            this.btnempleado.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnempleado.ForeColor = System.Drawing.Color.White;
            this.btnempleado.HoverState.Parent = this.btnempleado;
            this.btnempleado.Image = ((System.Drawing.Image)(resources.GetObject("btnempleado.Image")));
            this.btnempleado.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnempleado.ImageSize = new System.Drawing.Size(45, 45);
            this.btnempleado.Location = new System.Drawing.Point(3, 411);
            this.btnempleado.Name = "btnempleado";
            this.btnempleado.ShadowDecoration.Parent = this.btnempleado;
            this.btnempleado.Size = new System.Drawing.Size(219, 50);
            this.btnempleado.TabIndex = 5;
            this.btnempleado.Text = "Empleados";
            this.btnempleado.Click += new System.EventHandler(this.boton4_Click);
            // 
            // btnbuscar
            // 
            this.btnbuscar.BorderRadius = 5;
            this.btnbuscar.CheckedState.Parent = this.btnbuscar;
            this.btnbuscar.CustomImages.Parent = this.btnbuscar;
            this.btnbuscar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnbuscar.ForeColor = System.Drawing.Color.White;
            this.btnbuscar.HoverState.Parent = this.btnbuscar;
            this.btnbuscar.Image = ((System.Drawing.Image)(resources.GetObject("btnbuscar.Image")));
            this.btnbuscar.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnbuscar.ImageSize = new System.Drawing.Size(50, 45);
            this.btnbuscar.Location = new System.Drawing.Point(3, 472);
            this.btnbuscar.Name = "btnbuscar";
            this.btnbuscar.ShadowDecoration.Parent = this.btnbuscar;
            this.btnbuscar.Size = new System.Drawing.Size(219, 50);
            this.btnbuscar.TabIndex = 4;
            this.btnbuscar.Text = "Buscar";
            this.btnbuscar.Click += new System.EventHandler(this.boton3_Click);
            // 
            // btnactivos
            // 
            this.btnactivos.BorderRadius = 5;
            this.btnactivos.CheckedState.Parent = this.btnactivos;
            this.btnactivos.CustomImages.Parent = this.btnactivos;
            this.btnactivos.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnactivos.ForeColor = System.Drawing.Color.White;
            this.btnactivos.HoverState.Parent = this.btnactivos;
            this.btnactivos.Image = ((System.Drawing.Image)(resources.GetObject("btnactivos.Image")));
            this.btnactivos.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnactivos.ImageSize = new System.Drawing.Size(45, 45);
            this.btnactivos.Location = new System.Drawing.Point(3, 270);
            this.btnactivos.Name = "btnactivos";
            this.btnactivos.ShadowDecoration.Parent = this.btnactivos;
            this.btnactivos.Size = new System.Drawing.Size(219, 50);
            this.btnactivos.TabIndex = 3;
            this.btnactivos.Text = " Activos";
            this.btnactivos.Click += new System.EventHandler(this.boton2_Click);
            // 
            // btnhome
            // 
            this.btnhome.BorderRadius = 5;
            this.btnhome.CheckedState.Parent = this.btnhome;
            this.btnhome.CustomImages.Parent = this.btnhome;
            this.btnhome.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnhome.ForeColor = System.Drawing.Color.White;
            this.btnhome.HoverState.Parent = this.btnhome;
            this.btnhome.Image = ((System.Drawing.Image)(resources.GetObject("btnhome.Image")));
            this.btnhome.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnhome.ImageSize = new System.Drawing.Size(45, 45);
            this.btnhome.Location = new System.Drawing.Point(3, 201);
            this.btnhome.Name = "btnhome";
            this.btnhome.ShadowDecoration.Parent = this.btnhome;
            this.btnhome.Size = new System.Drawing.Size(219, 50);
            this.btnhome.TabIndex = 2;
            this.btnhome.Text = "Home";
            this.btnhome.Click += new System.EventHandler(this.boton1_Click);
            this.btnhome.MouseHover += new System.EventHandler(this.boton1_MouseHover);
            // 
            // bienvenida
            // 
            this.bienvenida.AutoSize = true;
            this.bienvenida.Font = new System.Drawing.Font("Times New Roman", 26F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.bienvenida.Location = new System.Drawing.Point(484, 9);
            this.bienvenida.Name = "bienvenida";
            this.bienvenida.Size = new System.Drawing.Size(244, 51);
            this.bienvenida.TabIndex = 11;
            this.bienvenida.Text = "Bienvenidos";
            this.bienvenida.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // labnombE
            // 
            this.labnombE.AutoSize = true;
            this.labnombE.Font = new System.Drawing.Font("Times New Roman", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.labnombE.Location = new System.Drawing.Point(472, 80);
            this.labnombE.Name = "labnombE";
            this.labnombE.Size = new System.Drawing.Size(268, 46);
            this.labnombE.TabIndex = 10;
            this.labnombE.Text = "A & N Finanzas ";
            this.labnombE.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.labnombE.Click += new System.EventHandler(this.labnombE_Click);
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BackColor = System.Drawing.Color.MediumAquamarine;
            this.guna2Panel3.BorderThickness = 10;
            this.guna2Panel3.Controls.Add(this.label4);
            this.guna2Panel3.Controls.Add(this.label3);
            this.guna2Panel3.Controls.Add(this.label2);
            this.guna2Panel3.Controls.Add(this.label1);
            this.guna2Panel3.Controls.Add(this.hola);
            this.guna2Panel3.Controls.Add(this.gunaCirclePictureBox5);
            this.guna2Panel3.Controls.Add(this.gunaCirclePictureBox4);
            this.guna2Panel3.Controls.Add(this.gunaCirclePictureBox3);
            this.guna2Panel3.Controls.Add(this.gunaCirclePictureBox2);
            this.guna2Panel3.Controls.Add(this.gunaCirclePictureBox1);
            this.guna2Panel3.Location = new System.Drawing.Point(251, 559);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.ShadowDecoration.Parent = this.guna2Panel3;
            this.guna2Panel3.Size = new System.Drawing.Size(782, 168);
            this.guna2Panel3.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label4.Location = new System.Drawing.Point(664, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 20);
            this.label4.TabIndex = 24;
            this.label4.Text = "AN_Finanzas";
            this.label4.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label3.Location = new System.Drawing.Point(519, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 20);
            this.label3.TabIndex = 23;
            this.label3.Text = "AN Finanzas RD";
            this.label3.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label2.Location = new System.Drawing.Point(362, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 20);
            this.label2.TabIndex = 22;
            this.label2.Text = "Plaza Naco 3er nive";
            this.label2.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label1.Location = new System.Drawing.Point(159, 135);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "A&NFinanzas@gmail.com";
            this.label1.Visible = false;
            // 
            // hola
            // 
            this.hola.AutoSize = true;
            this.hola.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hola.Location = new System.Drawing.Point(13, 135);
            this.hola.Name = "hola";
            this.hola.Size = new System.Drawing.Size(111, 20);
            this.hola.TabIndex = 15;
            this.hola.Text = "809-916-8978";
            this.hola.Visible = false;
            // 
            // gunaCirclePictureBox5
            // 
            this.gunaCirclePictureBox5.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox5.Image")));
            this.gunaCirclePictureBox5.Location = new System.Drawing.Point(651, 3);
            this.gunaCirclePictureBox5.Name = "gunaCirclePictureBox5";
            this.gunaCirclePictureBox5.Size = new System.Drawing.Size(120, 120);
            this.gunaCirclePictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox5.TabIndex = 20;
            this.gunaCirclePictureBox5.TabStop = false;
            this.gunaCirclePictureBox5.UseTransfarantBackground = false;
            this.gunaCirclePictureBox5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.gunaCirclePictureBox5_MouseMove);
            // 
            // gunaCirclePictureBox4
            // 
            this.gunaCirclePictureBox4.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox4.Image")));
            this.gunaCirclePictureBox4.Location = new System.Drawing.Point(507, 0);
            this.gunaCirclePictureBox4.Name = "gunaCirclePictureBox4";
            this.gunaCirclePictureBox4.Size = new System.Drawing.Size(120, 120);
            this.gunaCirclePictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox4.TabIndex = 19;
            this.gunaCirclePictureBox4.TabStop = false;
            this.gunaCirclePictureBox4.UseTransfarantBackground = false;
            this.gunaCirclePictureBox4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.gunaCirclePictureBox4_MouseMove);
            // 
            // gunaCirclePictureBox3
            // 
            this.gunaCirclePictureBox3.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox3.Image")));
            this.gunaCirclePictureBox3.Location = new System.Drawing.Point(369, 0);
            this.gunaCirclePictureBox3.Name = "gunaCirclePictureBox3";
            this.gunaCirclePictureBox3.Size = new System.Drawing.Size(120, 120);
            this.gunaCirclePictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox3.TabIndex = 18;
            this.gunaCirclePictureBox3.TabStop = false;
            this.gunaCirclePictureBox3.UseTransfarantBackground = false;
            this.gunaCirclePictureBox3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.gunaCirclePictureBox3_MouseMove);
            // 
            // gunaCirclePictureBox2
            // 
            this.gunaCirclePictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox2.Image")));
            this.gunaCirclePictureBox2.Location = new System.Drawing.Point(200, 0);
            this.gunaCirclePictureBox2.Name = "gunaCirclePictureBox2";
            this.gunaCirclePictureBox2.Size = new System.Drawing.Size(120, 120);
            this.gunaCirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox2.TabIndex = 16;
            this.gunaCirclePictureBox2.TabStop = false;
            this.gunaCirclePictureBox2.UseTransfarantBackground = false;
            this.gunaCirclePictureBox2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.gunaCirclePictureBox2_MouseMove);
            // 
            // gunaCirclePictureBox1
            // 
            this.gunaCirclePictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox1.Image")));
            this.gunaCirclePictureBox1.Location = new System.Drawing.Point(7, 3);
            this.gunaCirclePictureBox1.Name = "gunaCirclePictureBox1";
            this.gunaCirclePictureBox1.Size = new System.Drawing.Size(120, 120);
            this.gunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox1.TabIndex = 14;
            this.gunaCirclePictureBox1.TabStop = false;
            this.gunaCirclePictureBox1.UseTransfarantBackground = false;
            this.gunaCirclePictureBox1.Click += new System.EventHandler(this.gunaCirclePictureBox1_Click);
            this.gunaCirclePictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.gunaCirclePictureBox1_MouseMove);
            // 
            // guna2CirclePictureBox4
            // 
            this.guna2CirclePictureBox4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(79)))), ((int)(((byte)(114)))));
            this.guna2CirclePictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox4.Image")));
            this.guna2CirclePictureBox4.Location = new System.Drawing.Point(667, -2);
            this.guna2CirclePictureBox4.Name = "guna2CirclePictureBox4";
            this.guna2CirclePictureBox4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox4.ShadowDecoration.Parent = this.guna2CirclePictureBox4;
            this.guna2CirclePictureBox4.Size = new System.Drawing.Size(104, 106);
            this.guna2CirclePictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox4.TabIndex = 9;
            this.guna2CirclePictureBox4.TabStop = false;
            this.guna2CirclePictureBox4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.guna2CirclePictureBox4_MouseMove);
            // 
            // guna2CirclePictureBox3
            // 
            this.guna2CirclePictureBox3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(79)))), ((int)(((byte)(114)))));
            this.guna2CirclePictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox3.Image")));
            this.guna2CirclePictureBox3.Location = new System.Drawing.Point(523, -2);
            this.guna2CirclePictureBox3.Name = "guna2CirclePictureBox3";
            this.guna2CirclePictureBox3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox3.ShadowDecoration.Parent = this.guna2CirclePictureBox3;
            this.guna2CirclePictureBox3.Size = new System.Drawing.Size(104, 106);
            this.guna2CirclePictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox3.TabIndex = 5;
            this.guna2CirclePictureBox3.TabStop = false;
            this.guna2CirclePictureBox3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.guna2CirclePictureBox3_MouseMove);
            // 
            // guna2CirclePictureBox6
            // 
            this.guna2CirclePictureBox6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(79)))), ((int)(((byte)(114)))));
            this.guna2CirclePictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox6.Image")));
            this.guna2CirclePictureBox6.Location = new System.Drawing.Point(340, -2);
            this.guna2CirclePictureBox6.Name = "guna2CirclePictureBox6";
            this.guna2CirclePictureBox6.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox6.ShadowDecoration.Parent = this.guna2CirclePictureBox6;
            this.guna2CirclePictureBox6.Size = new System.Drawing.Size(127, 125);
            this.guna2CirclePictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox6.TabIndex = 8;
            this.guna2CirclePictureBox6.TabStop = false;
            this.guna2CirclePictureBox6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.guna2CirclePictureBox6_MouseMove);
            // 
            // facebook
            // 
            this.facebook.AutoSize = true;
            this.facebook.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.facebook.Location = new System.Drawing.Point(519, 126);
            this.facebook.Name = "facebook";
            this.facebook.Size = new System.Drawing.Size(128, 19);
            this.facebook.TabIndex = 15;
            this.facebook.Text = "A&N Finanzas RD";
            this.facebook.Visible = false;
            // 
            // guna2CirclePictureBox2
            // 
            this.guna2CirclePictureBox2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(79)))), ((int)(((byte)(114)))));
            this.guna2CirclePictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox2.Image")));
            this.guna2CirclePictureBox2.Location = new System.Drawing.Point(179, -2);
            this.guna2CirclePictureBox2.Name = "guna2CirclePictureBox2";
            this.guna2CirclePictureBox2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox2.ShadowDecoration.Parent = this.guna2CirclePictureBox2;
            this.guna2CirclePictureBox2.Size = new System.Drawing.Size(104, 106);
            this.guna2CirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox2.TabIndex = 4;
            this.guna2CirclePictureBox2.TabStop = false;
            this.guna2CirclePictureBox2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.guna2CirclePictureBox2_MouseMove);
            // 
            // guna2CirclePictureBox5
            // 
            this.guna2CirclePictureBox5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(79)))), ((int)(((byte)(114)))));
            this.guna2CirclePictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox5.Image")));
            this.guna2CirclePictureBox5.Location = new System.Drawing.Point(20, 0);
            this.guna2CirclePictureBox5.Name = "guna2CirclePictureBox5";
            this.guna2CirclePictureBox5.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox5.ShadowDecoration.Parent = this.guna2CirclePictureBox5;
            this.guna2CirclePictureBox5.Size = new System.Drawing.Size(104, 106);
            this.guna2CirclePictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox5.TabIndex = 7;
            this.guna2CirclePictureBox5.TabStop = false;
            this.guna2CirclePictureBox5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.guna2CirclePictureBox5_MouseMove);
            // 
            // telefono
            // 
            this.telefono.AutoSize = true;
            this.telefono.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.telefono.Location = new System.Drawing.Point(3, 126);
            this.telefono.Name = "telefono";
            this.telefono.Size = new System.Drawing.Size(111, 19);
            this.telefono.TabIndex = 12;
            this.telefono.Text = "809-916-8978";
            this.telefono.Visible = false;
            // 
            // Lemail
            // 
            this.Lemail.AutoSize = true;
            this.Lemail.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.Lemail.Location = new System.Drawing.Point(140, 126);
            this.Lemail.Name = "Lemail";
            this.Lemail.Size = new System.Drawing.Size(190, 19);
            this.Lemail.TabIndex = 14;
            this.Lemail.Text = "ANFinanzas@gmail.com";
            this.Lemail.Visible = false;
            // 
            // ubicacion
            // 
            this.ubicacion.AutoSize = true;
            this.ubicacion.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.ubicacion.Location = new System.Drawing.Point(351, 126);
            this.ubicacion.Name = "ubicacion";
            this.ubicacion.Size = new System.Drawing.Size(162, 19);
            this.ubicacion.TabIndex = 17;
            this.ubicacion.Text = "Plaza Naco 3er Nivel";
            this.ubicacion.Visible = false;
            // 
            // instagram
            // 
            this.instagram.AutoSize = true;
            this.instagram.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.instagram.Location = new System.Drawing.Point(663, 126);
            this.instagram.Name = "instagram";
            this.instagram.Size = new System.Drawing.Size(96, 19);
            this.instagram.TabIndex = 16;
            this.instagram.Text = "AN_Finazas";
            this.instagram.Visible = false;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.guna2Panel2.BorderThickness = 10;
            this.guna2Panel2.Controls.Add(this.instagram);
            this.guna2Panel2.Controls.Add(this.ubicacion);
            this.guna2Panel2.Controls.Add(this.Lemail);
            this.guna2Panel2.Controls.Add(this.telefono);
            this.guna2Panel2.Controls.Add(this.guna2CirclePictureBox5);
            this.guna2Panel2.Controls.Add(this.guna2CirclePictureBox2);
            this.guna2Panel2.Controls.Add(this.facebook);
            this.guna2Panel2.Controls.Add(this.guna2CirclePictureBox6);
            this.guna2Panel2.Controls.Add(this.guna2CirclePictureBox3);
            this.guna2Panel2.Controls.Add(this.guna2CirclePictureBox4);
            this.guna2Panel2.Location = new System.Drawing.Point(251, 559);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            this.guna2Panel2.Size = new System.Drawing.Size(782, 152);
            this.guna2Panel2.TabIndex = 13;
            // 
            // guna2CirclePictureBox7
            // 
            this.guna2CirclePictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox7.Image")));
            this.guna2CirclePictureBox7.Location = new System.Drawing.Point(480, 140);
            this.guna2CirclePictureBox7.Name = "guna2CirclePictureBox7";
            this.guna2CirclePictureBox7.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox7.ShadowDecoration.Parent = this.guna2CirclePictureBox7;
            this.guna2CirclePictureBox7.Size = new System.Drawing.Size(225, 226);
            this.guna2CirclePictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox7.TabIndex = 14;
            this.guna2CirclePictureBox7.TabStop = false;
            // 
            // lbhora
            // 
            this.lbhora.AutoSize = true;
            this.lbhora.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbhora.Location = new System.Drawing.Point(545, 413);
            this.lbhora.Name = "lbhora";
            this.lbhora.Size = new System.Drawing.Size(89, 34);
            this.lbhora.TabIndex = 15;
            this.lbhora.Text = "label5";
            // 
            // lbfecha
            // 
            this.lbfecha.AutoSize = true;
            this.lbfecha.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbfecha.Location = new System.Drawing.Point(545, 460);
            this.lbfecha.Name = "lbfecha";
            this.lbfecha.Size = new System.Drawing.Size(85, 32);
            this.lbfecha.TabIndex = 16;
            this.lbfecha.Text = "label6";
            this.lbfecha.Click += new System.EventHandler(this.label6_Click);
            // 
            // tiempo
            // 
            this.tiempo.Enabled = true;
            this.tiempo.Tick += new System.EventHandler(this.tiempo_Tick);
            // 
            // Formbienveida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumAquamarine;
            this.ClientSize = new System.Drawing.Size(1035, 739);
            this.Controls.Add(this.lbfecha);
            this.Controls.Add(this.lbhora);
            this.Controls.Add(this.guna2CirclePictureBox7);
            this.Controls.Add(this.guna2Panel3);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.bienvenida);
            this.Controls.Add(this.labnombE);
            this.Controls.Add(this.guna2Panel1);
            this.Name = "Formbienveida";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Formbienveida_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            this.guna2Panel3.ResumeLayout(false);
            this.guna2Panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox5)).EndInit();
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Button btnhome;
        private Guna.UI2.WinForms.Guna2Button btnintres;
        private Guna.UI2.WinForms.Guna2Button btnempleado;
        private Guna.UI2.WinForms.Guna2Button btnbuscar;
        private Guna.UI2.WinForms.Guna2Button btnactivos;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2Button btnreportes;
        private System.Windows.Forms.Label bienvenida;
        private Guna.UI2.WinForms.Guna2Button btnayuda;
        private Guna.UI2.WinForms.Guna2Button btnusuario;
        private System.Windows.Forms.Label labnombE;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox1;
        private System.Windows.Forms.Label hola;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox5;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox4;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox3;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox2;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox4;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox3;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox6;
        private System.Windows.Forms.Label facebook;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox2;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox5;
        private System.Windows.Forms.Label telefono;
        private System.Windows.Forms.Label Lemail;
        private System.Windows.Forms.Label ubicacion;
        private System.Windows.Forms.Label instagram;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox7;
        private System.Windows.Forms.Label usuanombre;
        private System.Windows.Forms.Label lbhora;
        private System.Windows.Forms.Label lbfecha;
        private System.Windows.Forms.Timer tiempo;
    }
}