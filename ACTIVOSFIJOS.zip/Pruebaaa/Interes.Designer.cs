﻿
namespace Pruebaaa
{
    partial class Interes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Interes));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.lab5 = new System.Windows.Forms.Label();
            this.lab4 = new System.Windows.Forms.Label();
            this.lab3 = new System.Windows.Forms.Label();
            this.lab2 = new System.Windows.Forms.Label();
            this.lab1 = new System.Windows.Forms.Label();
            this.guna5 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.guna4 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.guna3 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.guna2 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.guna1 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox2 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaCirclePictureBox1 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaCirclePictureBox2 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.digital = new System.Windows.Forms.Label();
            this.ciud = new System.Windows.Forms.Label();
            this.emer = new System.Windows.Forms.Label();
            this.rep = new System.Windows.Forms.Label();
            this.gunadigt = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.guna311 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.guna911 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaRD = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox2)).BeginInit();
            this.guna2Panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunadigt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna311)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna911)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaRD)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(141)))), ((int)(((byte)(117)))));
            this.guna2Panel1.Controls.Add(this.lab5);
            this.guna2Panel1.Controls.Add(this.lab4);
            this.guna2Panel1.Controls.Add(this.lab3);
            this.guna2Panel1.Controls.Add(this.lab2);
            this.guna2Panel1.Controls.Add(this.lab1);
            this.guna2Panel1.Controls.Add(this.guna5);
            this.guna2Panel1.Controls.Add(this.guna4);
            this.guna2Panel1.Controls.Add(this.guna3);
            this.guna2Panel1.Controls.Add(this.guna2);
            this.guna2Panel1.Controls.Add(this.guna1);
            this.guna2Panel1.Location = new System.Drawing.Point(823, 3);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(208, 667);
            this.guna2Panel1.TabIndex = 0;
            // 
            // lab5
            // 
            this.lab5.AutoSize = true;
            this.lab5.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lab5.Location = new System.Drawing.Point(41, 618);
            this.lab5.Name = "lab5";
            this.lab5.Size = new System.Drawing.Size(107, 20);
            this.lab5.TabIndex = 2;
            this.lab5.Text = "AN_Finanzas";
            this.lab5.Visible = false;
            // 
            // lab4
            // 
            this.lab4.AutoSize = true;
            this.lab4.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lab4.Location = new System.Drawing.Point(24, 485);
            this.lab4.Name = "lab4";
            this.lab4.Size = new System.Drawing.Size(129, 20);
            this.lab4.TabIndex = 2;
            this.lab4.Text = "AN Finanzas RD";
            this.lab4.Visible = false;
            // 
            // lab3
            // 
            this.lab3.AutoSize = true;
            this.lab3.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lab3.Location = new System.Drawing.Point(16, 359);
            this.lab3.Name = "lab3";
            this.lab3.Size = new System.Drawing.Size(151, 20);
            this.lab3.TabIndex = 20;
            this.lab3.Text = "Plaza Naco 3er nive";
            this.lab3.Visible = false;
            // 
            // lab2
            // 
            this.lab2.AutoSize = true;
            this.lab2.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lab2.Location = new System.Drawing.Point(3, 224);
            this.lab2.Name = "lab2";
            this.lab2.Size = new System.Drawing.Size(186, 20);
            this.lab2.TabIndex = 19;
            this.lab2.Text = "A&NFinanzas@gmail.com";
            this.lab2.Visible = false;
            // 
            // lab1
            // 
            this.lab1.AutoSize = true;
            this.lab1.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lab1.Location = new System.Drawing.Point(42, 99);
            this.lab1.Name = "lab1";
            this.lab1.Size = new System.Drawing.Size(111, 20);
            this.lab1.TabIndex = 1;
            this.lab1.Text = "809-916-8978";
            this.lab1.Visible = false;
            // 
            // guna5
            // 
            this.guna5.BaseColor = System.Drawing.Color.White;
            this.guna5.Image = ((System.Drawing.Image)(resources.GetObject("guna5.Image")));
            this.guna5.Location = new System.Drawing.Point(46, 508);
            this.guna5.Name = "guna5";
            this.guna5.Size = new System.Drawing.Size(83, 83);
            this.guna5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna5.TabIndex = 18;
            this.guna5.TabStop = false;
            this.guna5.UseTransfarantBackground = false;
            this.guna5.Click += new System.EventHandler(this.guna5_Click);
            this.guna5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.guna5_MouseMove);
            // 
            // guna4
            // 
            this.guna4.BaseColor = System.Drawing.Color.White;
            this.guna4.Image = ((System.Drawing.Image)(resources.GetObject("guna4.Image")));
            this.guna4.Location = new System.Drawing.Point(46, 382);
            this.guna4.Name = "guna4";
            this.guna4.Size = new System.Drawing.Size(83, 83);
            this.guna4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna4.TabIndex = 17;
            this.guna4.TabStop = false;
            this.guna4.UseTransfarantBackground = false;
            this.guna4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.guna4_MouseMove);
            // 
            // guna3
            // 
            this.guna3.BaseColor = System.Drawing.Color.White;
            this.guna3.Image = ((System.Drawing.Image)(resources.GetObject("guna3.Image")));
            this.guna3.Location = new System.Drawing.Point(46, 247);
            this.guna3.Name = "guna3";
            this.guna3.Size = new System.Drawing.Size(83, 83);
            this.guna3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna3.TabIndex = 16;
            this.guna3.TabStop = false;
            this.guna3.UseTransfarantBackground = false;
            this.guna3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.guna3_MouseMove);
            // 
            // guna2
            // 
            this.guna2.BaseColor = System.Drawing.Color.White;
            this.guna2.Image = ((System.Drawing.Image)(resources.GetObject("guna2.Image")));
            this.guna2.Location = new System.Drawing.Point(46, 122);
            this.guna2.Name = "guna2";
            this.guna2.Size = new System.Drawing.Size(83, 83);
            this.guna2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2.TabIndex = 15;
            this.guna2.TabStop = false;
            this.guna2.UseTransfarantBackground = false;
            this.guna2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.guna2_MouseMove);
            // 
            // guna1
            // 
            this.guna1.BaseColor = System.Drawing.Color.White;
            this.guna1.Image = ((System.Drawing.Image)(resources.GetObject("guna1.Image")));
            this.guna1.Location = new System.Drawing.Point(45, 3);
            this.guna1.Name = "guna1";
            this.guna1.Size = new System.Drawing.Size(83, 83);
            this.guna1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna1.TabIndex = 15;
            this.guna1.TabStop = false;
            this.guna1.UseTransfarantBackground = false;
            this.guna1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.guna1_MouseMove);
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox1.Image")));
            this.gunaPictureBox1.Location = new System.Drawing.Point(214, 250);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(260, 319);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox1.TabIndex = 24;
            this.gunaPictureBox1.TabStop = false;
            // 
            // gunaPictureBox2
            // 
            this.gunaPictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox2.Image")));
            this.gunaPictureBox2.Location = new System.Drawing.Point(520, 303);
            this.gunaPictureBox2.Name = "gunaPictureBox2";
            this.gunaPictureBox2.Size = new System.Drawing.Size(281, 311);
            this.gunaPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox2.TabIndex = 25;
            this.gunaPictureBox2.TabStop = false;
            // 
            // gunaCirclePictureBox1
            // 
            this.gunaCirclePictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox1.Image")));
            this.gunaCirclePictureBox1.Location = new System.Drawing.Point(265, 65);
            this.gunaCirclePictureBox1.Name = "gunaCirclePictureBox1";
            this.gunaCirclePictureBox1.Size = new System.Drawing.Size(147, 167);
            this.gunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox1.TabIndex = 39;
            this.gunaCirclePictureBox1.TabStop = false;
            this.gunaCirclePictureBox1.UseTransfarantBackground = false;
            this.gunaCirclePictureBox1.Click += new System.EventHandler(this.gunaCirclePictureBox1_Click);
            // 
            // gunaCirclePictureBox2
            // 
            this.gunaCirclePictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox2.Image")));
            this.gunaCirclePictureBox2.Location = new System.Drawing.Point(571, 125);
            this.gunaCirclePictureBox2.Name = "gunaCirclePictureBox2";
            this.gunaCirclePictureBox2.Size = new System.Drawing.Size(149, 167);
            this.gunaCirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox2.TabIndex = 40;
            this.gunaCirclePictureBox2.TabStop = false;
            this.gunaCirclePictureBox2.UseTransfarantBackground = false;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(141)))), ((int)(((byte)(117)))));
            this.guna2Panel2.Controls.Add(this.guna2ImageButton3);
            this.guna2Panel2.Controls.Add(this.digital);
            this.guna2Panel2.Controls.Add(this.ciud);
            this.guna2Panel2.Controls.Add(this.emer);
            this.guna2Panel2.Controls.Add(this.rep);
            this.guna2Panel2.Controls.Add(this.gunadigt);
            this.guna2Panel2.Controls.Add(this.guna311);
            this.guna2Panel2.Controls.Add(this.guna911);
            this.guna2Panel2.Controls.Add(this.gunaRD);
            this.guna2Panel2.Location = new System.Drawing.Point(1, 3);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            this.guna2Panel2.Size = new System.Drawing.Size(168, 667);
            this.guna2Panel2.TabIndex = 41;
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.CheckedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.Location = new System.Drawing.Point(19, 9);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.PressedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Size = new System.Drawing.Size(66, 65);
            this.guna2ImageButton3.TabIndex = 42;
            this.guna2ImageButton3.Click += new System.EventHandler(this.guna2ImageButton3_Click);
            // 
            // digital
            // 
            this.digital.AutoSize = true;
            this.digital.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.digital.Location = new System.Drawing.Point(15, 605);
            this.digital.Name = "digital";
            this.digital.Size = new System.Drawing.Size(136, 20);
            this.digital.TabIndex = 31;
            this.digital.Text = "Republica Digital";
            this.digital.Visible = false;
            // 
            // ciud
            // 
            this.ciud.AutoSize = true;
            this.ciud.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.ciud.Location = new System.Drawing.Point(2, 479);
            this.ciud.Name = "ciud";
            this.ciud.Size = new System.Drawing.Size(155, 20);
            this.ciud.TabIndex = 30;
            this.ciud.Text = "Atencion Ciudadana";
            this.ciud.Visible = false;
            // 
            // emer
            // 
            this.emer.AutoSize = true;
            this.emer.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.emer.Location = new System.Drawing.Point(17, 343);
            this.emer.Name = "emer";
            this.emer.Size = new System.Drawing.Size(96, 20);
            this.emer.TabIndex = 29;
            this.emer.Text = "Emergencia";
            this.emer.Visible = false;
            // 
            // rep
            // 
            this.rep.AutoSize = true;
            this.rep.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.rep.Location = new System.Drawing.Point(27, 199);
            this.rep.Name = "rep";
            this.rep.Size = new System.Drawing.Size(74, 20);
            this.rep.TabIndex = 28;
            this.rep.Text = "Rep.Dom";
            this.rep.Visible = false;
            // 
            // gunadigt
            // 
            this.gunadigt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.gunadigt.BaseColor = System.Drawing.Color.White;
            this.gunadigt.Image = ((System.Drawing.Image)(resources.GetObject("gunadigt.Image")));
            this.gunadigt.Location = new System.Drawing.Point(30, 528);
            this.gunadigt.Name = "gunadigt";
            this.gunadigt.Size = new System.Drawing.Size(83, 83);
            this.gunadigt.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunadigt.TabIndex = 27;
            this.gunadigt.TabStop = false;
            this.gunadigt.UseTransfarantBackground = false;
            // 
            // guna311
            // 
            this.guna311.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.guna311.BaseColor = System.Drawing.Color.White;
            this.guna311.Image = ((System.Drawing.Image)(resources.GetObject("guna311.Image")));
            this.guna311.Location = new System.Drawing.Point(30, 402);
            this.guna311.Name = "guna311";
            this.guna311.Size = new System.Drawing.Size(83, 83);
            this.guna311.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna311.TabIndex = 26;
            this.guna311.TabStop = false;
            this.guna311.UseTransfarantBackground = false;
            // 
            // guna911
            // 
            this.guna911.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.guna911.BaseColor = System.Drawing.Color.White;
            this.guna911.Image = ((System.Drawing.Image)(resources.GetObject("guna911.Image")));
            this.guna911.Location = new System.Drawing.Point(24, 247);
            this.guna911.Name = "guna911";
            this.guna911.Size = new System.Drawing.Size(83, 83);
            this.guna911.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna911.TabIndex = 25;
            this.guna911.TabStop = false;
            this.guna911.UseTransfarantBackground = false;
            // 
            // gunaRD
            // 
            this.gunaRD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.gunaRD.BaseColor = System.Drawing.Color.White;
            this.gunaRD.Image = ((System.Drawing.Image)(resources.GetObject("gunaRD.Image")));
            this.gunaRD.Location = new System.Drawing.Point(24, 122);
            this.gunaRD.Name = "gunaRD";
            this.gunaRD.Size = new System.Drawing.Size(83, 83);
            this.gunaRD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaRD.TabIndex = 24;
            this.gunaRD.TabStop = false;
            this.gunaRD.UseTransfarantBackground = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(327, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(360, 38);
            this.label1.TabIndex = 42;
            this.label1.Text = "Informacion de Interes!!";
            // 
            // Interes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1035, 676);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.gunaCirclePictureBox2);
            this.Controls.Add(this.gunaCirclePictureBox1);
            this.Controls.Add(this.gunaPictureBox2);
            this.Controls.Add(this.gunaPictureBox1);
            this.Controls.Add(this.guna2Panel1);
            this.Name = "Interes";
            this.Text = ".";
            this.Load += new System.EventHandler(this.Interes_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox2)).EndInit();
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunadigt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna311)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna911)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaRD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.Label lab5;
        private System.Windows.Forms.Label lab4;
        private System.Windows.Forms.Label lab3;
        private System.Windows.Forms.Label lab2;
        private System.Windows.Forms.Label lab1;
        private Guna.UI.WinForms.GunaCirclePictureBox guna5;
        private Guna.UI.WinForms.GunaCirclePictureBox guna4;
        private Guna.UI.WinForms.GunaCirclePictureBox guna3;
        private Guna.UI.WinForms.GunaCirclePictureBox guna2;
        private Guna.UI.WinForms.GunaCirclePictureBox guna1;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox2;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox1;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private System.Windows.Forms.Label digital;
        private System.Windows.Forms.Label ciud;
        private System.Windows.Forms.Label emer;
        private System.Windows.Forms.Label rep;
        private Guna.UI.WinForms.GunaCirclePictureBox gunadigt;
        private Guna.UI.WinForms.GunaCirclePictureBox guna311;
        private Guna.UI.WinForms.GunaCirclePictureBox guna911;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaRD;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
        private System.Windows.Forms.Label label1;
    }
}