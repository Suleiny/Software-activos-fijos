﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pruebaaa.Almacenamiento
{
    class Activos
    {
    public string  id_activo { get; set; }
       
    public string  codigo_activo { get; set; }
    public string  metros_activo { get; set; }
    public string tipos_activo { get; set; } 
    public string catastro_activo { get; set; }
    public string  propietario_activo { get; set; }
    public string  fecha_ingreso { get; set; }
    public string ValorInicial_activo { get; set; }
    public string ValorFinal_activo { get; set; }
    public string   marcaV_activo { get; set; }
    public string AñoIngreso_activo { get; set; }
    public string modelo_activo { get; set; }
     public string  cantidad_activo { get; set; }
     public string  TitPr_activo_activo { get; set; }






    }
}


