﻿
namespace Pruebaaa
{
    partial class Usuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Usuario));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.Pempleo = new Guna.UI2.WinForms.Guna2TextBox();
            this.soltero = new Guna.UI2.WinForms.Guna2TextBox();
            this.guardar = new Guna.UI2.WinForms.Guna2Button();
            this.Salario = new Guna.UI2.WinForms.Guna2TextBox();
            this.celular = new Guna.UI2.WinForms.Guna2TextBox();
            this.Edad = new Guna.UI2.WinForms.Guna2TextBox();
            this.fechaig = new Guna.UI2.WinForms.Guna2TextBox();
            this.direccionp = new Guna.UI2.WinForms.Guna2TextBox();
            this.telf = new Guna.UI2.WinForms.Guna2TextBox();
            this.Gemail = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2TextBox3 = new Guna.UI2.WinForms.Guna2TextBox();
            this.Pcedula = new Guna.UI2.WinForms.Guna2TextBox();
            this.Papellido = new Guna.UI2.WinForms.Guna2TextBox();
            this.Pnombre = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2DataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.datos = new System.Windows.Forms.Label();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.actuali = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BorderColor = System.Drawing.Color.Red;
            this.guna2Panel1.BorderRadius = 20;
            this.guna2Panel1.Controls.Add(this.actuali);
            this.guna2Panel1.Controls.Add(this.Pempleo);
            this.guna2Panel1.Controls.Add(this.soltero);
            this.guna2Panel1.Controls.Add(this.guardar);
            this.guna2Panel1.Controls.Add(this.Salario);
            this.guna2Panel1.Controls.Add(this.celular);
            this.guna2Panel1.Controls.Add(this.Edad);
            this.guna2Panel1.Controls.Add(this.fechaig);
            this.guna2Panel1.Controls.Add(this.direccionp);
            this.guna2Panel1.Controls.Add(this.telf);
            this.guna2Panel1.Controls.Add(this.Gemail);
            this.guna2Panel1.Controls.Add(this.guna2TextBox3);
            this.guna2Panel1.Controls.Add(this.Pcedula);
            this.guna2Panel1.Controls.Add(this.Papellido);
            this.guna2Panel1.Controls.Add(this.Pnombre);
            this.guna2Panel1.ForeColor = System.Drawing.Color.Crimson;
            this.guna2Panel1.Location = new System.Drawing.Point(226, 12);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(806, 442);
            this.guna2Panel1.TabIndex = 0;
            this.guna2Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2Panel1_Paint);
            // 
            // Pempleo
            // 
            this.Pempleo.BorderRadius = 5;
            this.Pempleo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Pempleo.DefaultText = "";
            this.Pempleo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Pempleo.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Pempleo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Pempleo.DisabledState.Parent = this.Pempleo;
            this.Pempleo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Pempleo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Pempleo.FocusedState.Parent = this.Pempleo;
            this.Pempleo.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pempleo.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Pempleo.HoverState.Parent = this.Pempleo;
            this.Pempleo.Location = new System.Drawing.Point(4, 330);
            this.Pempleo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Pempleo.Name = "Pempleo";
            this.Pempleo.PasswordChar = '\0';
            this.Pempleo.PlaceholderForeColor = System.Drawing.Color.Black;
            this.Pempleo.PlaceholderText = "Ocupacion";
            this.Pempleo.SelectedText = "";
            this.Pempleo.ShadowDecoration.Parent = this.Pempleo;
            this.Pempleo.Size = new System.Drawing.Size(256, 48);
            this.Pempleo.TabIndex = 16;
            // 
            // soltero
            // 
            this.soltero.BorderRadius = 5;
            this.soltero.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.soltero.DefaultText = "";
            this.soltero.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.soltero.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.soltero.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.soltero.DisabledState.Parent = this.soltero;
            this.soltero.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.soltero.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.soltero.FocusedState.Parent = this.soltero;
            this.soltero.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.soltero.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.soltero.HoverState.Parent = this.soltero;
            this.soltero.Location = new System.Drawing.Point(4, 265);
            this.soltero.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.soltero.Name = "soltero";
            this.soltero.PasswordChar = '\0';
            this.soltero.PlaceholderForeColor = System.Drawing.Color.Black;
            this.soltero.PlaceholderText = "Estado civil";
            this.soltero.SelectedText = "";
            this.soltero.ShadowDecoration.Parent = this.soltero;
            this.soltero.Size = new System.Drawing.Size(256, 48);
            this.soltero.TabIndex = 14;
            // 
            // guardar
            // 
            this.guardar.BackColor = System.Drawing.Color.White;
            this.guardar.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.guardar.BorderRadius = 5;
            this.guardar.BorderThickness = 5;
            this.guardar.CheckedState.Parent = this.guardar;
            this.guardar.CustomImages.Parent = this.guardar;
            this.guardar.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.guardar.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.guardar.ForeColor = System.Drawing.Color.Black;
            this.guardar.HoverState.Parent = this.guardar;
            this.guardar.Location = new System.Drawing.Point(551, 333);
            this.guardar.Name = "guardar";
            this.guardar.ShadowDecoration.Parent = this.guardar;
            this.guardar.Size = new System.Drawing.Size(246, 45);
            this.guardar.TabIndex = 13;
            this.guardar.Text = "Registrar";
            this.guardar.Click += new System.EventHandler(this.guardar_Click);
            // 
            // Salario
            // 
            this.Salario.BorderRadius = 5;
            this.Salario.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Salario.DefaultText = "";
            this.Salario.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Salario.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Salario.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Salario.DisabledState.Parent = this.Salario;
            this.Salario.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Salario.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Salario.FocusedState.Parent = this.Salario;
            this.Salario.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Salario.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Salario.HoverState.Parent = this.Salario;
            this.Salario.Location = new System.Drawing.Point(546, 265);
            this.Salario.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Salario.Name = "Salario";
            this.Salario.PasswordChar = '\0';
            this.Salario.PlaceholderForeColor = System.Drawing.Color.Black;
            this.Salario.PlaceholderText = "Salario";
            this.Salario.SelectedText = "";
            this.Salario.ShadowDecoration.Parent = this.Salario;
            this.Salario.Size = new System.Drawing.Size(256, 48);
            this.Salario.TabIndex = 12;
            // 
            // celular
            // 
            this.celular.BorderRadius = 5;
            this.celular.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.celular.DefaultText = "";
            this.celular.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.celular.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.celular.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.celular.DisabledState.Parent = this.celular;
            this.celular.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.celular.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.celular.FocusedState.Parent = this.celular;
            this.celular.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.celular.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.celular.HoverState.Parent = this.celular;
            this.celular.Location = new System.Drawing.Point(546, 190);
            this.celular.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.celular.Name = "celular";
            this.celular.PasswordChar = '\0';
            this.celular.PlaceholderForeColor = System.Drawing.Color.Black;
            this.celular.PlaceholderText = "Telefono";
            this.celular.SelectedText = "";
            this.celular.ShadowDecoration.Parent = this.celular;
            this.celular.Size = new System.Drawing.Size(256, 48);
            this.celular.TabIndex = 9;
            // 
            // Edad
            // 
            this.Edad.BorderRadius = 5;
            this.Edad.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Edad.DefaultText = "";
            this.Edad.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Edad.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Edad.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Edad.DisabledState.Parent = this.Edad;
            this.Edad.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Edad.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Edad.FocusedState.Parent = this.Edad;
            this.Edad.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Edad.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Edad.HoverState.Parent = this.Edad;
            this.Edad.Location = new System.Drawing.Point(277, 116);
            this.Edad.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Edad.Name = "Edad";
            this.Edad.PasswordChar = '\0';
            this.Edad.PlaceholderForeColor = System.Drawing.Color.Black;
            this.Edad.PlaceholderText = "Edad";
            this.Edad.SelectedText = "";
            this.Edad.ShadowDecoration.Parent = this.Edad;
            this.Edad.Size = new System.Drawing.Size(256, 48);
            this.Edad.TabIndex = 5;
            // 
            // fechaig
            // 
            this.fechaig.BorderRadius = 5;
            this.fechaig.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.fechaig.DefaultText = "";
            this.fechaig.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.fechaig.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.fechaig.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.fechaig.DisabledState.Parent = this.fechaig;
            this.fechaig.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.fechaig.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.fechaig.FocusedState.Parent = this.fechaig;
            this.fechaig.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fechaig.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.fechaig.HoverState.Parent = this.fechaig;
            this.fechaig.Location = new System.Drawing.Point(278, 330);
            this.fechaig.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.fechaig.Name = "fechaig";
            this.fechaig.PasswordChar = '\0';
            this.fechaig.PlaceholderForeColor = System.Drawing.Color.Black;
            this.fechaig.PlaceholderText = "Fecha ingreso a la empresa";
            this.fechaig.SelectedText = "";
            this.fechaig.ShadowDecoration.Parent = this.fechaig;
            this.fechaig.Size = new System.Drawing.Size(255, 46);
            this.fechaig.TabIndex = 10;
            // 
            // direccionp
            // 
            this.direccionp.BorderRadius = 5;
            this.direccionp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.direccionp.DefaultText = "";
            this.direccionp.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.direccionp.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.direccionp.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.direccionp.DisabledState.Parent = this.direccionp;
            this.direccionp.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.direccionp.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.direccionp.FocusedState.Parent = this.direccionp;
            this.direccionp.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.direccionp.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.direccionp.HoverState.Parent = this.direccionp;
            this.direccionp.Location = new System.Drawing.Point(276, 265);
            this.direccionp.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.direccionp.Name = "direccionp";
            this.direccionp.PasswordChar = '\0';
            this.direccionp.PlaceholderForeColor = System.Drawing.Color.Black;
            this.direccionp.PlaceholderText = "Direccion";
            this.direccionp.SelectedText = "";
            this.direccionp.ShadowDecoration.Parent = this.direccionp;
            this.direccionp.Size = new System.Drawing.Size(256, 48);
            this.direccionp.TabIndex = 8;
            // 
            // telf
            // 
            this.telf.BorderRadius = 5;
            this.telf.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.telf.DefaultText = "";
            this.telf.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.telf.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.telf.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.telf.DisabledState.Parent = this.telf;
            this.telf.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.telf.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.telf.FocusedState.Parent = this.telf;
            this.telf.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.telf.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.telf.HoverState.Parent = this.telf;
            this.telf.Location = new System.Drawing.Point(277, 190);
            this.telf.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.telf.Name = "telf";
            this.telf.PasswordChar = '\0';
            this.telf.PlaceholderForeColor = System.Drawing.Color.Black;
            this.telf.PlaceholderText = "Celular";
            this.telf.SelectedText = "";
            this.telf.ShadowDecoration.Parent = this.telf;
            this.telf.Size = new System.Drawing.Size(255, 46);
            this.telf.TabIndex = 7;
            // 
            // Gemail
            // 
            this.Gemail.BorderRadius = 5;
            this.Gemail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Gemail.DefaultText = "";
            this.Gemail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Gemail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Gemail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Gemail.DisabledState.Parent = this.Gemail;
            this.Gemail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Gemail.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Gemail.FocusedState.Parent = this.Gemail;
            this.Gemail.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gemail.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Gemail.HoverState.Parent = this.Gemail;
            this.Gemail.Location = new System.Drawing.Point(4, 190);
            this.Gemail.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Gemail.Name = "Gemail";
            this.Gemail.PasswordChar = '\0';
            this.Gemail.PlaceholderForeColor = System.Drawing.Color.Black;
            this.Gemail.PlaceholderText = "Correo";
            this.Gemail.SelectedText = "";
            this.Gemail.ShadowDecoration.Parent = this.Gemail;
            this.Gemail.Size = new System.Drawing.Size(256, 48);
            this.Gemail.TabIndex = 6;
            // 
            // guna2TextBox3
            // 
            this.guna2TextBox3.BorderRadius = 5;
            this.guna2TextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox3.DefaultText = "";
            this.guna2TextBox3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3.DisabledState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.FocusedState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox3.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.HoverState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.Location = new System.Drawing.Point(551, 118);
            this.guna2TextBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.guna2TextBox3.Name = "guna2TextBox3";
            this.guna2TextBox3.PasswordChar = '\0';
            this.guna2TextBox3.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox3.PlaceholderText = "Fecha Nacimiento";
            this.guna2TextBox3.SelectedText = "";
            this.guna2TextBox3.ShadowDecoration.Parent = this.guna2TextBox3;
            this.guna2TextBox3.Size = new System.Drawing.Size(255, 46);
            this.guna2TextBox3.TabIndex = 4;
            // 
            // Pcedula
            // 
            this.Pcedula.BorderRadius = 5;
            this.Pcedula.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Pcedula.DefaultText = "";
            this.Pcedula.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Pcedula.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Pcedula.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Pcedula.DisabledState.Parent = this.Pcedula;
            this.Pcedula.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Pcedula.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Pcedula.FocusedState.Parent = this.Pcedula;
            this.Pcedula.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pcedula.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Pcedula.HoverState.Parent = this.Pcedula;
            this.Pcedula.Location = new System.Drawing.Point(4, 116);
            this.Pcedula.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Pcedula.Name = "Pcedula";
            this.Pcedula.PasswordChar = '\0';
            this.Pcedula.PlaceholderForeColor = System.Drawing.Color.Black;
            this.Pcedula.PlaceholderText = "Cedula";
            this.Pcedula.SelectedText = "";
            this.Pcedula.ShadowDecoration.Parent = this.Pcedula;
            this.Pcedula.Size = new System.Drawing.Size(256, 48);
            this.Pcedula.TabIndex = 3;
            // 
            // Papellido
            // 
            this.Papellido.BorderRadius = 5;
            this.Papellido.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Papellido.DefaultText = "";
            this.Papellido.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Papellido.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Papellido.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Papellido.DisabledState.Parent = this.Papellido;
            this.Papellido.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Papellido.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Papellido.FocusedState.Parent = this.Papellido;
            this.Papellido.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Papellido.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Papellido.HoverState.Parent = this.Papellido;
            this.Papellido.Location = new System.Drawing.Point(412, 27);
            this.Papellido.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Papellido.Name = "Papellido";
            this.Papellido.PasswordChar = '\0';
            this.Papellido.PlaceholderForeColor = System.Drawing.Color.Black;
            this.Papellido.PlaceholderText = "Apellido";
            this.Papellido.SelectedText = "";
            this.Papellido.ShadowDecoration.Parent = this.Papellido;
            this.Papellido.Size = new System.Drawing.Size(256, 48);
            this.Papellido.TabIndex = 2;
            // 
            // Pnombre
            // 
            this.Pnombre.BorderRadius = 5;
            this.Pnombre.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Pnombre.DefaultText = "";
            this.Pnombre.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Pnombre.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Pnombre.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Pnombre.DisabledState.Parent = this.Pnombre;
            this.Pnombre.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Pnombre.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Pnombre.FocusedState.Parent = this.Pnombre;
            this.Pnombre.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pnombre.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Pnombre.HoverState.Parent = this.Pnombre;
            this.Pnombre.Location = new System.Drawing.Point(97, 27);
            this.Pnombre.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Pnombre.Name = "Pnombre";
            this.Pnombre.PasswordChar = '\0';
            this.Pnombre.PlaceholderForeColor = System.Drawing.Color.Black;
            this.Pnombre.PlaceholderText = "Nombre";
            this.Pnombre.SelectedText = "";
            this.Pnombre.ShadowDecoration.Parent = this.Pnombre;
            this.Pnombre.Size = new System.Drawing.Size(255, 46);
            this.Pnombre.TabIndex = 1;
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox3.Image")));
            this.guna2PictureBox3.Location = new System.Drawing.Point(12, 98);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(205, 208);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox3.TabIndex = 24;
            this.guna2PictureBox3.TabStop = false;
            // 
            // guna2DataGridView1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.guna2DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.guna2DataGridView1.BackgroundColor = System.Drawing.Color.Moccasin;
            this.guna2DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.guna2DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.guna2DataGridView1.ColumnHeadersHeight = 4;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.guna2DataGridView1.EnableHeadersVisualStyles = false;
            this.guna2DataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.Location = new System.Drawing.Point(0, 457);
            this.guna2DataGridView1.Name = "guna2DataGridView1";
            this.guna2DataGridView1.RowHeadersVisible = false;
            this.guna2DataGridView1.RowHeadersWidth = 51;
            this.guna2DataGridView1.RowTemplate.Height = 24;
            this.guna2DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.guna2DataGridView1.Size = new System.Drawing.Size(791, 263);
            this.guna2DataGridView1.TabIndex = 25;
            this.guna2DataGridView1.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.BackColor = System.Drawing.Color.Moccasin;
            this.guna2DataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Height = 4;
            this.guna2DataGridView1.ThemeStyle.ReadOnly = false;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.guna2DataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Height = 24;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.guna2DataGridView1_CellContentClick);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.Location = new System.Drawing.Point(800, 460);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(228, 233);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 26;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.UseTransparentBackground = true;
            // 
            // datos
            // 
            this.datos.AutoSize = true;
            this.datos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.datos.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.datos.ForeColor = System.Drawing.Color.Cornsilk;
            this.datos.Location = new System.Drawing.Point(7, 424);
            this.datos.Name = "datos";
            this.datos.Size = new System.Drawing.Size(204, 30);
            this.datos.TabIndex = 14;
            this.datos.Text = "Datos Registrados";
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.CheckedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.Location = new System.Drawing.Point(12, 12);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.PressedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Size = new System.Drawing.Size(66, 65);
            this.guna2ImageButton3.TabIndex = 43;
            this.guna2ImageButton3.Click += new System.EventHandler(this.guna2ImageButton3_Click);
            // 
            // actuali
            // 
            this.actuali.BackColor = System.Drawing.Color.White;
            this.actuali.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.actuali.BorderRadius = 5;
            this.actuali.BorderThickness = 5;
            this.actuali.CheckedState.Parent = this.actuali;
            this.actuali.CustomImages.Parent = this.actuali;
            this.actuali.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.actuali.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.actuali.ForeColor = System.Drawing.Color.Black;
            this.actuali.HoverState.Parent = this.actuali;
            this.actuali.Location = new System.Drawing.Point(551, 397);
            this.actuali.Name = "actuali";
            this.actuali.ShadowDecoration.Parent = this.actuali;
            this.actuali.Size = new System.Drawing.Size(246, 45);
            this.actuali.TabIndex = 17;
            this.actuali.Text = "Modificar";
            // 
            // Usuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(79)))), ((int)(((byte)(114)))));
            this.ClientSize = new System.Drawing.Size(1035, 721);
            this.Controls.Add(this.guna2ImageButton3);
            this.Controls.Add(this.datos);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.guna2PictureBox3);
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.guna2DataGridView1);
            this.Name = "Usuario";
            this.Text = "Form3";
            this.guna2Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2TextBox Salario;
        private Guna.UI2.WinForms.Guna2TextBox fechaig;
        private Guna.UI2.WinForms.Guna2TextBox telf;
        private Guna.UI2.WinForms.Guna2TextBox direccionp;
        private Guna.UI2.WinForms.Guna2TextBox celular;
        private Guna.UI2.WinForms.Guna2TextBox Gemail;
        private Guna.UI2.WinForms.Guna2TextBox Edad;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox3;
        private Guna.UI2.WinForms.Guna2TextBox Pcedula;
        private Guna.UI2.WinForms.Guna2TextBox Papellido;
        private Guna.UI2.WinForms.Guna2TextBox Pnombre;
        private Guna.UI2.WinForms.Guna2Button guardar;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private System.Windows.Forms.Label datos;
        private Guna.UI2.WinForms.Guna2TextBox soltero;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
        private Guna.UI2.WinForms.Guna2TextBox Pempleo;
        private Guna.UI2.WinForms.Guna2Button actuali;
    }
}