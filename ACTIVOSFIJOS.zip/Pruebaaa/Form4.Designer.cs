﻿
namespace Pruebaaa
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2ImageButton4 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton2 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton1 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.carpropietarios = new Guna.UI2.WinForms.Guna2TextBox();
            this.carMarca = new Guna.UI2.WinForms.Guna2TextBox();
            this.carfecha = new Guna.UI2.WinForms.Guna2TextBox();
            this.carcantidad = new Guna.UI2.WinForms.Guna2TextBox();
            this.valor2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.valor1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.caryeard = new Guna.UI2.WinForms.Guna2TextBox();
            this.carmodelo = new Guna.UI2.WinForms.Guna2TextBox();
            this.carcodigo = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.datos = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.error = new System.Windows.Forms.ErrorProvider(this.components);
            this.labregi = new System.Windows.Forms.Label();
            this.guna2CirclePictureBox7 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.labnombE = new System.Windows.Forms.Label();
            this.radiocod = new Guna.UI2.WinForms.Guna2RadioButton();
            this.radiomatri = new Guna.UI2.WinForms.Guna2RadioButton();
            this.radiomod = new Guna.UI2.WinForms.Guna2RadioButton();
            this.radfecha = new Guna.UI2.WinForms.Guna2RadioButton();
            this.txtmatricula = new Guna.UI2.WinForms.Guna2TextBox();
            this.btnpdf = new Guna.UI2.WinForms.Guna2Button();
            this.BUSCUSER = new Guna.UI2.WinForms.Guna2TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.error)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox3.Image")));
            this.guna2PictureBox3.Location = new System.Drawing.Point(875, 70);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(205, 208);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox3.TabIndex = 29;
            this.guna2PictureBox3.TabStop = false;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BorderColor = System.Drawing.Color.Black;
            this.guna2Panel1.BorderRadius = 20;
            this.guna2Panel1.Controls.Add(this.txtmatricula);
            this.guna2Panel1.Controls.Add(this.labregi);
            this.guna2Panel1.Controls.Add(this.guna2ImageButton4);
            this.guna2Panel1.Controls.Add(this.guna2ImageButton2);
            this.guna2Panel1.Controls.Add(this.guna2ImageButton1);
            this.guna2Panel1.Controls.Add(this.carpropietarios);
            this.guna2Panel1.Controls.Add(this.carMarca);
            this.guna2Panel1.Controls.Add(this.carfecha);
            this.guna2Panel1.Controls.Add(this.carcantidad);
            this.guna2Panel1.Controls.Add(this.valor2);
            this.guna2Panel1.Controls.Add(this.valor1);
            this.guna2Panel1.Controls.Add(this.caryeard);
            this.guna2Panel1.Controls.Add(this.guna2PictureBox3);
            this.guna2Panel1.Controls.Add(this.carmodelo);
            this.guna2Panel1.Controls.Add(this.carcodigo);
            this.guna2Panel1.Location = new System.Drawing.Point(276, 12);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(1123, 381);
            this.guna2Panel1.TabIndex = 27;
            // 
            // guna2ImageButton4
            // 
            this.guna2ImageButton4.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.CheckedState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.HoverState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton4.Image")));
            this.guna2ImageButton4.ImageRotate = 0F;
            this.guna2ImageButton4.Location = new System.Drawing.Point(365, 296);
            this.guna2ImageButton4.Name = "guna2ImageButton4";
            this.guna2ImageButton4.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.PressedState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.Size = new System.Drawing.Size(68, 73);
            this.guna2ImageButton4.TabIndex = 46;
            this.guna2ImageButton4.Click += new System.EventHandler(this.guna2ImageButton4_Click);
            // 
            // guna2ImageButton2
            // 
            this.guna2ImageButton2.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.CheckedState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.HoverState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton2.Image")));
            this.guna2ImageButton2.ImageRotate = 0F;
            this.guna2ImageButton2.Location = new System.Drawing.Point(742, 296);
            this.guna2ImageButton2.Name = "guna2ImageButton2";
            this.guna2ImageButton2.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.PressedState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.Size = new System.Drawing.Size(68, 73);
            this.guna2ImageButton2.TabIndex = 44;
            this.guna2ImageButton2.Click += new System.EventHandler(this.guna2ImageButton2_Click);
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.CheckedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.Location = new System.Drawing.Point(12, -4);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.PressedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Size = new System.Drawing.Size(53, 55);
            this.guna2ImageButton3.TabIndex = 37;
            this.guna2ImageButton3.Click += new System.EventHandler(this.guna2ImageButton3_Click);
            // 
            // guna2ImageButton1
            // 
            this.guna2ImageButton1.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.CheckedState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.HoverState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton1.Image")));
            this.guna2ImageButton1.ImageRotate = 0F;
            this.guna2ImageButton1.Location = new System.Drawing.Point(558, 296);
            this.guna2ImageButton1.Name = "guna2ImageButton1";
            this.guna2ImageButton1.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.PressedState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.Size = new System.Drawing.Size(68, 73);
            this.guna2ImageButton1.TabIndex = 45;
            this.guna2ImageButton1.Click += new System.EventHandler(this.guna2ImageButton1_Click);
            // 
            // carpropietarios
            // 
            this.carpropietarios.BorderRadius = 5;
            this.carpropietarios.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.carpropietarios.DefaultText = "";
            this.carpropietarios.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.carpropietarios.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.carpropietarios.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.carpropietarios.DisabledState.Parent = this.carpropietarios;
            this.carpropietarios.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.carpropietarios.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.carpropietarios.FocusedState.Parent = this.carpropietarios;
            this.carpropietarios.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carpropietarios.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.carpropietarios.HoverState.Parent = this.carpropietarios;
            this.carpropietarios.Location = new System.Drawing.Point(30, 321);
            this.carpropietarios.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.carpropietarios.Name = "carpropietarios";
            this.carpropietarios.PasswordChar = '\0';
            this.carpropietarios.PlaceholderForeColor = System.Drawing.Color.Black;
            this.carpropietarios.PlaceholderText = "Propietario";
            this.carpropietarios.SelectedText = "";
            this.carpropietarios.ShadowDecoration.Parent = this.carpropietarios;
            this.carpropietarios.Size = new System.Drawing.Size(256, 48);
            this.carpropietarios.TabIndex = 12;
            this.carpropietarios.Validated += new System.EventHandler(this.carpropietarios_Validated);
            // 
            // carMarca
            // 
            this.carMarca.BorderRadius = 5;
            this.carMarca.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.carMarca.DefaultText = "";
            this.carMarca.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.carMarca.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.carMarca.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.carMarca.DisabledState.Parent = this.carMarca;
            this.carMarca.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.carMarca.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.carMarca.FocusedState.Parent = this.carMarca;
            this.carMarca.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carMarca.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.carMarca.HoverState.Parent = this.carMarca;
            this.carMarca.Location = new System.Drawing.Point(578, 70);
            this.carMarca.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.carMarca.Name = "carMarca";
            this.carMarca.PasswordChar = '\0';
            this.carMarca.PlaceholderForeColor = System.Drawing.Color.Black;
            this.carMarca.PlaceholderText = "Marca";
            this.carMarca.SelectedText = "";
            this.carMarca.ShadowDecoration.Parent = this.carMarca;
            this.carMarca.Size = new System.Drawing.Size(256, 48);
            this.carMarca.TabIndex = 5;
            this.carMarca.Validated += new System.EventHandler(this.carMarca_Validated);
            // 
            // carfecha
            // 
            this.carfecha.BorderRadius = 5;
            this.carfecha.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.carfecha.DefaultText = "";
            this.carfecha.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.carfecha.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.carfecha.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.carfecha.DisabledState.Parent = this.carfecha;
            this.carfecha.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.carfecha.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.carfecha.FocusedState.Parent = this.carfecha;
            this.carfecha.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carfecha.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.carfecha.HoverState.Parent = this.carfecha;
            this.carfecha.Location = new System.Drawing.Point(577, 239);
            this.carfecha.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.carfecha.Name = "carfecha";
            this.carfecha.PasswordChar = '\0';
            this.carfecha.PlaceholderForeColor = System.Drawing.Color.Black;
            this.carfecha.PlaceholderText = "Fecha de Ingreso";
            this.carfecha.SelectedText = "";
            this.carfecha.ShadowDecoration.Parent = this.carfecha;
            this.carfecha.Size = new System.Drawing.Size(256, 48);
            this.carfecha.TabIndex = 11;
            this.carfecha.Validated += new System.EventHandler(this.carfecha_Validated);
            // 
            // carcantidad
            // 
            this.carcantidad.BorderRadius = 5;
            this.carcantidad.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.carcantidad.DefaultText = "";
            this.carcantidad.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.carcantidad.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.carcantidad.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.carcantidad.DisabledState.Parent = this.carcantidad;
            this.carcantidad.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.carcantidad.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.carcantidad.FocusedState.Parent = this.carcantidad;
            this.carcantidad.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carcantidad.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.carcantidad.HoverState.Parent = this.carcantidad;
            this.carcantidad.Location = new System.Drawing.Point(578, 160);
            this.carcantidad.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.carcantidad.Name = "carcantidad";
            this.carcantidad.PasswordChar = '\0';
            this.carcantidad.PlaceholderForeColor = System.Drawing.Color.Black;
            this.carcantidad.PlaceholderText = "Cantidad";
            this.carcantidad.SelectedText = "";
            this.carcantidad.ShadowDecoration.Parent = this.carcantidad;
            this.carcantidad.Size = new System.Drawing.Size(255, 46);
            this.carcantidad.TabIndex = 7;
            this.carcantidad.Validated += new System.EventHandler(this.carcantidad_Validated);
            // 
            // valor2
            // 
            this.valor2.BorderRadius = 5;
            this.valor2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.valor2.DefaultText = "";
            this.valor2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.valor2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.valor2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.valor2.DisabledState.Parent = this.valor2;
            this.valor2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.valor2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.valor2.FocusedState.Parent = this.valor2;
            this.valor2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valor2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.valor2.HoverState.Parent = this.valor2;
            this.valor2.Location = new System.Drawing.Point(305, 239);
            this.valor2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.valor2.Name = "valor2";
            this.valor2.PasswordChar = '\0';
            this.valor2.PlaceholderForeColor = System.Drawing.Color.Black;
            this.valor2.PlaceholderText = "Precio Actual";
            this.valor2.SelectedText = "";
            this.valor2.ShadowDecoration.Parent = this.valor2;
            this.valor2.Size = new System.Drawing.Size(256, 48);
            this.valor2.TabIndex = 6;
            this.valor2.Validated += new System.EventHandler(this.valor2_Validated);
            // 
            // valor1
            // 
            this.valor1.BorderRadius = 5;
            this.valor1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.valor1.DefaultText = "";
            this.valor1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.valor1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.valor1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.valor1.DisabledState.Parent = this.valor1;
            this.valor1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.valor1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.valor1.FocusedState.Parent = this.valor1;
            this.valor1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valor1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.valor1.HoverState.Parent = this.valor1;
            this.valor1.Location = new System.Drawing.Point(31, 239);
            this.valor1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.valor1.Name = "valor1";
            this.valor1.PasswordChar = '\0';
            this.valor1.PlaceholderForeColor = System.Drawing.Color.Black;
            this.valor1.PlaceholderText = "Precio  Inicial";
            this.valor1.SelectedText = "";
            this.valor1.ShadowDecoration.Parent = this.valor1;
            this.valor1.Size = new System.Drawing.Size(255, 46);
            this.valor1.TabIndex = 4;
            this.valor1.Validated += new System.EventHandler(this.valor1_Validated);
            // 
            // caryeard
            // 
            this.caryeard.BorderRadius = 5;
            this.caryeard.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.caryeard.DefaultText = "";
            this.caryeard.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.caryeard.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.caryeard.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.caryeard.DisabledState.Parent = this.caryeard;
            this.caryeard.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.caryeard.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.caryeard.FocusedState.Parent = this.caryeard;
            this.caryeard.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.caryeard.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.caryeard.HoverState.Parent = this.caryeard;
            this.caryeard.Location = new System.Drawing.Point(305, 160);
            this.caryeard.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caryeard.Name = "caryeard";
            this.caryeard.PasswordChar = '\0';
            this.caryeard.PlaceholderForeColor = System.Drawing.Color.Black;
            this.caryeard.PlaceholderText = "Año";
            this.caryeard.SelectedText = "";
            this.caryeard.ShadowDecoration.Parent = this.caryeard;
            this.caryeard.Size = new System.Drawing.Size(256, 48);
            this.caryeard.TabIndex = 3;
            this.caryeard.TextChanged += new System.EventHandler(this.caryeard_TextChanged);
            // 
            // carmodelo
            // 
            this.carmodelo.BorderRadius = 5;
            this.carmodelo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.carmodelo.DefaultText = "";
            this.carmodelo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.carmodelo.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.carmodelo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.carmodelo.DisabledState.Parent = this.carmodelo;
            this.carmodelo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.carmodelo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.carmodelo.FocusedState.Parent = this.carmodelo;
            this.carmodelo.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carmodelo.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.carmodelo.HoverState.Parent = this.carmodelo;
            this.carmodelo.Location = new System.Drawing.Point(30, 160);
            this.carmodelo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.carmodelo.Name = "carmodelo";
            this.carmodelo.PasswordChar = '\0';
            this.carmodelo.PlaceholderForeColor = System.Drawing.Color.Black;
            this.carmodelo.PlaceholderText = "Modelo";
            this.carmodelo.SelectedText = "";
            this.carmodelo.ShadowDecoration.Parent = this.carmodelo;
            this.carmodelo.Size = new System.Drawing.Size(256, 48);
            this.carmodelo.TabIndex = 2;
            this.carmodelo.Validated += new System.EventHandler(this.carmodelo_Validated);
            // 
            // carcodigo
            // 
            this.carcodigo.BorderRadius = 5;
            this.carcodigo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.carcodigo.DefaultText = "";
            this.carcodigo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.carcodigo.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.carcodigo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.carcodigo.DisabledState.Parent = this.carcodigo;
            this.carcodigo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.carcodigo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.carcodigo.FocusedState.Parent = this.carcodigo;
            this.carcodigo.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carcodigo.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.carcodigo.HoverState.Parent = this.carcodigo;
            this.carcodigo.Location = new System.Drawing.Point(32, 70);
            this.carcodigo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.carcodigo.Name = "carcodigo";
            this.carcodigo.PasswordChar = '\0';
            this.carcodigo.PlaceholderForeColor = System.Drawing.Color.Black;
            this.carcodigo.PlaceholderText = "Codigo";
            this.carcodigo.SelectedText = "";
            this.carcodigo.ShadowDecoration.Parent = this.carcodigo;
            this.carcodigo.Size = new System.Drawing.Size(255, 46);
            this.carcodigo.TabIndex = 1;
            this.carcodigo.Validated += new System.EventHandler(this.carcodigo_Validated);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.Location = new System.Drawing.Point(8, 484);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(203, 210);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 31;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.UseTransparentBackground = true;
            // 
            // datos
            // 
            this.datos.AutoSize = true;
            this.datos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.datos.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.datos.ForeColor = System.Drawing.Color.Cornsilk;
            this.datos.Location = new System.Drawing.Point(7, 697);
            this.datos.Name = "datos";
            this.datos.Size = new System.Drawing.Size(204, 30);
            this.datos.TabIndex = 32;
            this.datos.Text = "Datos Registrados";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Times New Roman", 7.8F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Teal;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(77)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView1.Location = new System.Drawing.Point(236, 465);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(77)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1210, 344);
            this.dataGridView1.TabIndex = 42;
            // 
            // error
            // 
            this.error.ContainerControl = this;
            // 
            // labregi
            // 
            this.labregi.AutoSize = true;
            this.labregi.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labregi.Location = new System.Drawing.Point(386, 7);
            this.labregi.Name = "labregi";
            this.labregi.Size = new System.Drawing.Size(261, 32);
            this.labregi.TabIndex = 43;
            this.labregi.Text = "Registro de Vehiculos";
            // 
            // guna2CirclePictureBox7
            // 
            this.guna2CirclePictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox7.Image")));
            this.guna2CirclePictureBox7.Location = new System.Drawing.Point(33, 77);
            this.guna2CirclePictureBox7.Name = "guna2CirclePictureBox7";
            this.guna2CirclePictureBox7.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox7.ShadowDecoration.Parent = this.guna2CirclePictureBox7;
            this.guna2CirclePictureBox7.Size = new System.Drawing.Size(178, 180);
            this.guna2CirclePictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox7.TabIndex = 45;
            this.guna2CirclePictureBox7.TabStop = false;
            // 
            // labnombE
            // 
            this.labnombE.AutoSize = true;
            this.labnombE.Font = new System.Drawing.Font("Times New Roman", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.labnombE.Location = new System.Drawing.Point(5, 274);
            this.labnombE.Name = "labnombE";
            this.labnombE.Size = new System.Drawing.Size(229, 39);
            this.labnombE.TabIndex = 43;
            this.labnombE.Text = "A & N Finanzas ";
            this.labnombE.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // radiocod
            // 
            this.radiocod.AutoSize = true;
            this.radiocod.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.radiocod.CheckedState.BorderThickness = 0;
            this.radiocod.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.radiocod.CheckedState.InnerColor = System.Drawing.Color.White;
            this.radiocod.CheckedState.InnerOffset = -4;
            this.radiocod.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiocod.Location = new System.Drawing.Point(687, 419);
            this.radiocod.Name = "radiocod";
            this.radiocod.Size = new System.Drawing.Size(90, 27);
            this.radiocod.TabIndex = 50;
            this.radiocod.Text = "Codigo";
            this.radiocod.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.radiocod.UncheckedState.BorderThickness = 2;
            this.radiocod.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.radiocod.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // radiomatri
            // 
            this.radiomatri.AutoSize = true;
            this.radiomatri.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.radiomatri.CheckedState.BorderThickness = 0;
            this.radiomatri.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.radiomatri.CheckedState.InnerColor = System.Drawing.Color.White;
            this.radiomatri.CheckedState.InnerOffset = -4;
            this.radiomatri.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiomatri.Location = new System.Drawing.Point(834, 419);
            this.radiomatri.Name = "radiomatri";
            this.radiomatri.Size = new System.Drawing.Size(113, 27);
            this.radiomatri.TabIndex = 51;
            this.radiomatri.Text = "Matricula";
            this.radiomatri.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.radiomatri.UncheckedState.BorderThickness = 2;
            this.radiomatri.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.radiomatri.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.radiomatri.CheckedChanged += new System.EventHandler(this.radiomatri_CheckedChanged);
            this.radiomatri.Click += new System.EventHandler(this.radiomatri_Click);
            // 
            // radiomod
            // 
            this.radiomod.AutoSize = true;
            this.radiomod.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.radiomod.CheckedState.BorderThickness = 0;
            this.radiomod.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.radiomod.CheckedState.InnerColor = System.Drawing.Color.White;
            this.radiomod.CheckedState.InnerOffset = -4;
            this.radiomod.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiomod.Location = new System.Drawing.Point(1015, 419);
            this.radiomod.Name = "radiomod";
            this.radiomod.Size = new System.Drawing.Size(94, 27);
            this.radiomod.TabIndex = 52;
            this.radiomod.Text = "Modelo";
            this.radiomod.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.radiomod.UncheckedState.BorderThickness = 2;
            this.radiomod.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.radiomod.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // radfecha
            // 
            this.radfecha.AutoSize = true;
            this.radfecha.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.radfecha.CheckedState.BorderThickness = 0;
            this.radfecha.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.radfecha.CheckedState.InnerColor = System.Drawing.Color.White;
            this.radfecha.CheckedState.InnerOffset = -4;
            this.radfecha.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radfecha.Location = new System.Drawing.Point(1139, 419);
            this.radfecha.Name = "radfecha";
            this.radfecha.Size = new System.Drawing.Size(81, 27);
            this.radfecha.TabIndex = 53;
            this.radfecha.Text = "Fecha";
            this.radfecha.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.radfecha.UncheckedState.BorderThickness = 2;
            this.radfecha.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.radfecha.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // txtmatricula
            // 
            this.txtmatricula.BorderRadius = 5;
            this.txtmatricula.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtmatricula.DefaultText = "";
            this.txtmatricula.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtmatricula.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtmatricula.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtmatricula.DisabledState.Parent = this.txtmatricula;
            this.txtmatricula.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtmatricula.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtmatricula.FocusedState.Parent = this.txtmatricula;
            this.txtmatricula.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmatricula.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtmatricula.HoverState.Parent = this.txtmatricula;
            this.txtmatricula.Location = new System.Drawing.Point(305, 70);
            this.txtmatricula.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtmatricula.Name = "txtmatricula";
            this.txtmatricula.PasswordChar = '\0';
            this.txtmatricula.PlaceholderForeColor = System.Drawing.Color.Black;
            this.txtmatricula.PlaceholderText = "Matricula";
            this.txtmatricula.SelectedText = "";
            this.txtmatricula.ShadowDecoration.Parent = this.txtmatricula;
            this.txtmatricula.Size = new System.Drawing.Size(256, 48);
            this.txtmatricula.TabIndex = 47;
            // 
            // btnpdf
            // 
            this.btnpdf.BorderRadius = 5;
            this.btnpdf.CheckedState.Parent = this.btnpdf;
            this.btnpdf.CustomImages.Parent = this.btnpdf;
            this.btnpdf.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(172)))), ((int)(((byte)(193)))));
            this.btnpdf.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnpdf.ForeColor = System.Drawing.Color.White;
            this.btnpdf.HoverState.Parent = this.btnpdf;
            this.btnpdf.Image = ((System.Drawing.Image)(resources.GetObject("btnpdf.Image")));
            this.btnpdf.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnpdf.ImageSize = new System.Drawing.Size(45, 45);
            this.btnpdf.Location = new System.Drawing.Point(1239, 409);
            this.btnpdf.Name = "btnpdf";
            this.btnpdf.ShadowDecoration.Parent = this.btnpdf;
            this.btnpdf.Size = new System.Drawing.Size(207, 50);
            this.btnpdf.TabIndex = 48;
            this.btnpdf.Text = "Export PDF";
            // 
            // BUSCUSER
            // 
            this.BUSCUSER.BorderRadius = 5;
            this.BUSCUSER.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BUSCUSER.DefaultText = "";
            this.BUSCUSER.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BUSCUSER.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BUSCUSER.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BUSCUSER.DisabledState.Parent = this.BUSCUSER;
            this.BUSCUSER.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BUSCUSER.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BUSCUSER.FocusedState.Parent = this.BUSCUSER;
            this.BUSCUSER.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUSCUSER.ForeColor = System.Drawing.Color.Black;
            this.BUSCUSER.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BUSCUSER.HoverState.Parent = this.BUSCUSER;
            this.BUSCUSER.Location = new System.Drawing.Point(236, 413);
            this.BUSCUSER.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BUSCUSER.Name = "BUSCUSER";
            this.BUSCUSER.PasswordChar = '\0';
            this.BUSCUSER.PlaceholderText = "Ingresar Busquedad";
            this.BUSCUSER.SelectedText = "";
            this.BUSCUSER.ShadowDecoration.Parent = this.BUSCUSER;
            this.BUSCUSER.Size = new System.Drawing.Size(433, 46);
            this.BUSCUSER.TabIndex = 41;
            this.BUSCUSER.TextChanged += new System.EventHandler(this.BUSCUSER_TextChanged);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(79)))), ((int)(((byte)(114)))));
            this.ClientSize = new System.Drawing.Size(1458, 812);
            this.Controls.Add(this.btnpdf);
            this.Controls.Add(this.radfecha);
            this.Controls.Add(this.radiomod);
            this.Controls.Add(this.radiomatri);
            this.Controls.Add(this.radiocod);
            this.Controls.Add(this.guna2CirclePictureBox7);
            this.Controls.Add(this.labnombE);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.guna2ImageButton3);
            this.Controls.Add(this.BUSCUSER);
            this.Controls.Add(this.datos);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.guna2Panel1);
            this.Name = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.error)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2TextBox carpropietarios;
        private Guna.UI2.WinForms.Guna2TextBox carMarca;
        private Guna.UI2.WinForms.Guna2TextBox carfecha;
        private Guna.UI2.WinForms.Guna2TextBox carcantidad;
        private Guna.UI2.WinForms.Guna2TextBox valor2;
        private Guna.UI2.WinForms.Guna2TextBox valor1;
        private Guna.UI2.WinForms.Guna2TextBox caryeard;
        private Guna.UI2.WinForms.Guna2TextBox carmodelo;
        private Guna.UI2.WinForms.Guna2TextBox carcodigo;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private System.Windows.Forms.Label datos;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton4;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton2;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ErrorProvider error;
        private System.Windows.Forms.Label labregi;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox7;
        private System.Windows.Forms.Label labnombE;
        private Guna.UI2.WinForms.Guna2TextBox txtmatricula;
        private Guna.UI2.WinForms.Guna2RadioButton radfecha;
        private Guna.UI2.WinForms.Guna2RadioButton radiomod;
        private Guna.UI2.WinForms.Guna2RadioButton radiomatri;
        private Guna.UI2.WinForms.Guna2RadioButton radiocod;
        private Guna.UI2.WinForms.Guna2Button btnpdf;
        private Guna.UI2.WinForms.Guna2TextBox BUSCUSER;
    }
}