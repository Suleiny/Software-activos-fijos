﻿
namespace Pruebaaa
{
    partial class Edificio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Edificio));
            this.datos = new System.Windows.Forms.Label();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.titulo = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.txtcarpropietarios = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtmetro = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtcarfecha = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtcarcantidad = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtvalor2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtvalor1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtdeuda = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtubicacion = new Guna.UI2.WinForms.Guna2TextBox();
            this.Txtcatastro = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2ImageButton1 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.BUSCUSER = new Guna.UI2.WinForms.Guna2TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.guna2ImageButton4 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton2 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton5 = new Guna.UI2.WinForms.Guna2ImageButton();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // datos
            // 
            this.datos.AutoSize = true;
            this.datos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.datos.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.datos.ForeColor = System.Drawing.Color.Cornsilk;
            this.datos.Location = new System.Drawing.Point(8, 712);
            this.datos.Name = "datos";
            this.datos.Size = new System.Drawing.Size(204, 30);
            this.datos.TabIndex = 42;
            this.datos.Text = "Datos Registrados";
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.Location = new System.Drawing.Point(-3, 476);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(228, 233);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 41;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.UseTransparentBackground = true;
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox3.Image")));
            this.guna2PictureBox3.Location = new System.Drawing.Point(879, 60);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(205, 208);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox3.TabIndex = 39;
            this.guna2PictureBox3.TabStop = false;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(97)))), ((int)(((byte)(141)))));
            this.guna2Panel1.BorderColor = System.Drawing.Color.Black;
            this.guna2Panel1.BorderRadius = 20;
            this.guna2Panel1.Controls.Add(this.guna2ImageButton4);
            this.guna2Panel1.Controls.Add(this.guna2ImageButton2);
            this.guna2Panel1.Controls.Add(this.guna2ImageButton5);
            this.guna2Panel1.Controls.Add(this.titulo);
            this.guna2Panel1.Controls.Add(this.guna2ImageButton3);
            this.guna2Panel1.Controls.Add(this.txtcarpropietarios);
            this.guna2Panel1.Controls.Add(this.txtmetro);
            this.guna2Panel1.Controls.Add(this.txtcarfecha);
            this.guna2Panel1.Controls.Add(this.txtcarcantidad);
            this.guna2Panel1.Controls.Add(this.txtvalor2);
            this.guna2Panel1.Controls.Add(this.txtvalor1);
            this.guna2Panel1.Controls.Add(this.txtdeuda);
            this.guna2Panel1.Controls.Add(this.txtubicacion);
            this.guna2Panel1.Controls.Add(this.Txtcatastro);
            this.guna2Panel1.Location = new System.Drawing.Point(2, 3);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(871, 405);
            this.guna2Panel1.TabIndex = 38;
            this.guna2Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2Panel1_Paint);
            // 
            // titulo
            // 
            this.titulo.BorderRadius = 5;
            this.titulo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.titulo.DefaultText = "";
            this.titulo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.titulo.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.titulo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.titulo.DisabledState.Parent = this.titulo;
            this.titulo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.titulo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.titulo.FocusedState.Parent = this.titulo;
            this.titulo.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titulo.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.titulo.HoverState.Parent = this.titulo;
            this.titulo.Location = new System.Drawing.Point(7, 325);
            this.titulo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.titulo.Name = "titulo";
            this.titulo.PasswordChar = '\0';
            this.titulo.PlaceholderForeColor = System.Drawing.Color.Black;
            this.titulo.PlaceholderText = "Titulo de Propiedad";
            this.titulo.SelectedText = "";
            this.titulo.ShadowDecoration.Parent = this.titulo;
            this.titulo.Size = new System.Drawing.Size(256, 48);
            this.titulo.TabIndex = 44;
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.CheckedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.Location = new System.Drawing.Point(0, 0);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.PressedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Size = new System.Drawing.Size(59, 51);
            this.guna2ImageButton3.TabIndex = 43;
            this.guna2ImageButton3.Click += new System.EventHandler(this.guna2ImageButton3_Click);
            // 
            // txtcarpropietarios
            // 
            this.txtcarpropietarios.BorderRadius = 5;
            this.txtcarpropietarios.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcarpropietarios.DefaultText = "";
            this.txtcarpropietarios.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtcarpropietarios.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtcarpropietarios.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcarpropietarios.DisabledState.Parent = this.txtcarpropietarios;
            this.txtcarpropietarios.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcarpropietarios.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcarpropietarios.FocusedState.Parent = this.txtcarpropietarios;
            this.txtcarpropietarios.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcarpropietarios.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcarpropietarios.HoverState.Parent = this.txtcarpropietarios;
            this.txtcarpropietarios.Location = new System.Drawing.Point(564, 253);
            this.txtcarpropietarios.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtcarpropietarios.Name = "txtcarpropietarios";
            this.txtcarpropietarios.PasswordChar = '\0';
            this.txtcarpropietarios.PlaceholderForeColor = System.Drawing.Color.Black;
            this.txtcarpropietarios.PlaceholderText = "Propietario";
            this.txtcarpropietarios.SelectedText = "";
            this.txtcarpropietarios.ShadowDecoration.Parent = this.txtcarpropietarios;
            this.txtcarpropietarios.Size = new System.Drawing.Size(256, 48);
            this.txtcarpropietarios.TabIndex = 12;
            // 
            // txtmetro
            // 
            this.txtmetro.BorderRadius = 5;
            this.txtmetro.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtmetro.DefaultText = "";
            this.txtmetro.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtmetro.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtmetro.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtmetro.DisabledState.Parent = this.txtmetro;
            this.txtmetro.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtmetro.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtmetro.FocusedState.Parent = this.txtmetro;
            this.txtmetro.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmetro.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtmetro.HoverState.Parent = this.txtmetro;
            this.txtmetro.Location = new System.Drawing.Point(289, 55);
            this.txtmetro.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtmetro.Name = "txtmetro";
            this.txtmetro.PasswordChar = '\0';
            this.txtmetro.PlaceholderForeColor = System.Drawing.Color.Black;
            this.txtmetro.PlaceholderText = "Metros de la propiedad";
            this.txtmetro.SelectedText = "";
            this.txtmetro.ShadowDecoration.Parent = this.txtmetro;
            this.txtmetro.Size = new System.Drawing.Size(256, 48);
            this.txtmetro.TabIndex = 5;
            // 
            // txtcarfecha
            // 
            this.txtcarfecha.BorderRadius = 5;
            this.txtcarfecha.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcarfecha.DefaultText = "";
            this.txtcarfecha.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtcarfecha.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtcarfecha.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcarfecha.DisabledState.Parent = this.txtcarfecha;
            this.txtcarfecha.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcarfecha.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcarfecha.FocusedState.Parent = this.txtcarfecha;
            this.txtcarfecha.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcarfecha.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcarfecha.HoverState.Parent = this.txtcarfecha;
            this.txtcarfecha.Location = new System.Drawing.Point(289, 251);
            this.txtcarfecha.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtcarfecha.Name = "txtcarfecha";
            this.txtcarfecha.PasswordChar = '\0';
            this.txtcarfecha.PlaceholderForeColor = System.Drawing.Color.Black;
            this.txtcarfecha.PlaceholderText = "Fecha de Ingreso";
            this.txtcarfecha.SelectedText = "";
            this.txtcarfecha.ShadowDecoration.Parent = this.txtcarfecha;
            this.txtcarfecha.Size = new System.Drawing.Size(256, 48);
            this.txtcarfecha.TabIndex = 11;
            // 
            // txtcarcantidad
            // 
            this.txtcarcantidad.BorderRadius = 5;
            this.txtcarcantidad.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcarcantidad.DefaultText = "";
            this.txtcarcantidad.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtcarcantidad.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtcarcantidad.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcarcantidad.DisabledState.Parent = this.txtcarcantidad;
            this.txtcarcantidad.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcarcantidad.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcarcantidad.FocusedState.Parent = this.txtcarcantidad;
            this.txtcarcantidad.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcarcantidad.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcarcantidad.HoverState.Parent = this.txtcarcantidad;
            this.txtcarcantidad.Location = new System.Drawing.Point(565, 157);
            this.txtcarcantidad.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtcarcantidad.Name = "txtcarcantidad";
            this.txtcarcantidad.PasswordChar = '\0';
            this.txtcarcantidad.PlaceholderForeColor = System.Drawing.Color.Black;
            this.txtcarcantidad.PlaceholderText = "Cantidad";
            this.txtcarcantidad.SelectedText = "";
            this.txtcarcantidad.ShadowDecoration.Parent = this.txtcarcantidad;
            this.txtcarcantidad.Size = new System.Drawing.Size(255, 46);
            this.txtcarcantidad.TabIndex = 7;
            // 
            // txtvalor2
            // 
            this.txtvalor2.BorderRadius = 5;
            this.txtvalor2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtvalor2.DefaultText = "";
            this.txtvalor2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtvalor2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtvalor2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtvalor2.DisabledState.Parent = this.txtvalor2;
            this.txtvalor2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtvalor2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtvalor2.FocusedState.Parent = this.txtvalor2;
            this.txtvalor2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvalor2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtvalor2.HoverState.Parent = this.txtvalor2;
            this.txtvalor2.Location = new System.Drawing.Point(289, 155);
            this.txtvalor2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtvalor2.Name = "txtvalor2";
            this.txtvalor2.PasswordChar = '\0';
            this.txtvalor2.PlaceholderForeColor = System.Drawing.Color.Black;
            this.txtvalor2.PlaceholderText = "Valor Actual";
            this.txtvalor2.SelectedText = "";
            this.txtvalor2.ShadowDecoration.Parent = this.txtvalor2;
            this.txtvalor2.Size = new System.Drawing.Size(256, 48);
            this.txtvalor2.TabIndex = 6;
            // 
            // txtvalor1
            // 
            this.txtvalor1.BorderRadius = 5;
            this.txtvalor1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtvalor1.DefaultText = "";
            this.txtvalor1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtvalor1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtvalor1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtvalor1.DisabledState.Parent = this.txtvalor1;
            this.txtvalor1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtvalor1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtvalor1.FocusedState.Parent = this.txtvalor1;
            this.txtvalor1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvalor1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtvalor1.HoverState.Parent = this.txtvalor1;
            this.txtvalor1.Location = new System.Drawing.Point(3, 155);
            this.txtvalor1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtvalor1.Name = "txtvalor1";
            this.txtvalor1.PasswordChar = '\0';
            this.txtvalor1.PlaceholderForeColor = System.Drawing.Color.Black;
            this.txtvalor1.PlaceholderText = "Valor  Inicial";
            this.txtvalor1.SelectedText = "";
            this.txtvalor1.ShadowDecoration.Parent = this.txtvalor1;
            this.txtvalor1.Size = new System.Drawing.Size(255, 46);
            this.txtvalor1.TabIndex = 4;
            // 
            // txtdeuda
            // 
            this.txtdeuda.BorderRadius = 5;
            this.txtdeuda.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtdeuda.DefaultText = "";
            this.txtdeuda.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtdeuda.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtdeuda.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtdeuda.DisabledState.Parent = this.txtdeuda;
            this.txtdeuda.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtdeuda.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtdeuda.FocusedState.Parent = this.txtdeuda;
            this.txtdeuda.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdeuda.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtdeuda.HoverState.Parent = this.txtdeuda;
            this.txtdeuda.Location = new System.Drawing.Point(7, 251);
            this.txtdeuda.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtdeuda.Name = "txtdeuda";
            this.txtdeuda.PasswordChar = '\0';
            this.txtdeuda.PlaceholderForeColor = System.Drawing.Color.Black;
            this.txtdeuda.PlaceholderText = "Deuda";
            this.txtdeuda.SelectedText = "";
            this.txtdeuda.ShadowDecoration.Parent = this.txtdeuda;
            this.txtdeuda.Size = new System.Drawing.Size(256, 48);
            this.txtdeuda.TabIndex = 3;
            // 
            // txtubicacion
            // 
            this.txtubicacion.BorderRadius = 5;
            this.txtubicacion.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtubicacion.DefaultText = "";
            this.txtubicacion.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtubicacion.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtubicacion.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtubicacion.DisabledState.Parent = this.txtubicacion;
            this.txtubicacion.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtubicacion.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtubicacion.FocusedState.Parent = this.txtubicacion;
            this.txtubicacion.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtubicacion.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtubicacion.HoverState.Parent = this.txtubicacion;
            this.txtubicacion.Location = new System.Drawing.Point(564, 57);
            this.txtubicacion.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtubicacion.Name = "txtubicacion";
            this.txtubicacion.PasswordChar = '\0';
            this.txtubicacion.PlaceholderForeColor = System.Drawing.Color.Black;
            this.txtubicacion.PlaceholderText = "Ubicacion";
            this.txtubicacion.SelectedText = "";
            this.txtubicacion.ShadowDecoration.Parent = this.txtubicacion;
            this.txtubicacion.Size = new System.Drawing.Size(256, 48);
            this.txtubicacion.TabIndex = 2;
            // 
            // Txtcatastro
            // 
            this.Txtcatastro.BorderRadius = 5;
            this.Txtcatastro.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Txtcatastro.DefaultText = "";
            this.Txtcatastro.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Txtcatastro.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Txtcatastro.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Txtcatastro.DisabledState.Parent = this.Txtcatastro;
            this.Txtcatastro.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Txtcatastro.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Txtcatastro.FocusedState.Parent = this.Txtcatastro;
            this.Txtcatastro.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txtcatastro.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Txtcatastro.HoverState.Parent = this.Txtcatastro;
            this.Txtcatastro.Location = new System.Drawing.Point(3, 57);
            this.Txtcatastro.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Txtcatastro.Name = "Txtcatastro";
            this.Txtcatastro.PasswordChar = '\0';
            this.Txtcatastro.PlaceholderForeColor = System.Drawing.Color.Black;
            this.Txtcatastro.PlaceholderText = "Catastro";
            this.Txtcatastro.SelectedText = "";
            this.Txtcatastro.ShadowDecoration.Parent = this.Txtcatastro;
            this.Txtcatastro.Size = new System.Drawing.Size(255, 46);
            this.Txtcatastro.TabIndex = 1;
            // 
            // guna2ImageButton1
            // 
            this.guna2ImageButton1.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.CheckedState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.HoverState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton1.Image")));
            this.guna2ImageButton1.ImageRotate = 0F;
            this.guna2ImageButton1.Location = new System.Drawing.Point(916, 410);
            this.guna2ImageButton1.Name = "guna2ImageButton1";
            this.guna2ImageButton1.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.PressedState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.Size = new System.Drawing.Size(67, 60);
            this.guna2ImageButton1.TabIndex = 44;
            // 
            // BUSCUSER
            // 
            this.BUSCUSER.BorderRadius = 5;
            this.BUSCUSER.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BUSCUSER.DefaultText = "";
            this.BUSCUSER.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BUSCUSER.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BUSCUSER.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BUSCUSER.DisabledState.Parent = this.BUSCUSER;
            this.BUSCUSER.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BUSCUSER.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BUSCUSER.FocusedState.Parent = this.BUSCUSER;
            this.BUSCUSER.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUSCUSER.ForeColor = System.Drawing.Color.Black;
            this.BUSCUSER.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BUSCUSER.HoverState.Parent = this.BUSCUSER;
            this.BUSCUSER.Location = new System.Drawing.Point(329, 424);
            this.BUSCUSER.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BUSCUSER.Name = "BUSCUSER";
            this.BUSCUSER.PasswordChar = '\0';
            this.BUSCUSER.PlaceholderText = "Ingresar Busquedad";
            this.BUSCUSER.SelectedText = "";
            this.BUSCUSER.ShadowDecoration.Parent = this.BUSCUSER;
            this.BUSCUSER.Size = new System.Drawing.Size(580, 46);
            this.BUSCUSER.TabIndex = 43;
            this.BUSCUSER.KeyUp += new System.Windows.Forms.KeyEventHandler(this.BUSCUSER_KeyUp);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(218, 476);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(866, 358);
            this.dataGridView1.TabIndex = 45;
            // 
            // guna2ImageButton4
            // 
            this.guna2ImageButton4.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.CheckedState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.HoverState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton4.Image")));
            this.guna2ImageButton4.ImageRotate = 0F;
            this.guna2ImageButton4.Location = new System.Drawing.Point(327, 320);
            this.guna2ImageButton4.Name = "guna2ImageButton4";
            this.guna2ImageButton4.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.PressedState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.Size = new System.Drawing.Size(68, 73);
            this.guna2ImageButton4.TabIndex = 47;
            this.guna2ImageButton4.Click += new System.EventHandler(this.guna2ImageButton4_Click);
            // 
            // guna2ImageButton2
            // 
            this.guna2ImageButton2.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.CheckedState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.HoverState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton2.Image")));
            this.guna2ImageButton2.ImageRotate = 0F;
            this.guna2ImageButton2.Location = new System.Drawing.Point(696, 320);
            this.guna2ImageButton2.Name = "guna2ImageButton2";
            this.guna2ImageButton2.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.PressedState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.Size = new System.Drawing.Size(68, 73);
            this.guna2ImageButton2.TabIndex = 45;
            // 
            // guna2ImageButton5
            // 
            this.guna2ImageButton5.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton5.CheckedState.Parent = this.guna2ImageButton5;
            this.guna2ImageButton5.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton5.HoverState.Parent = this.guna2ImageButton5;
            this.guna2ImageButton5.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton5.Image")));
            this.guna2ImageButton5.ImageRotate = 0F;
            this.guna2ImageButton5.Location = new System.Drawing.Point(506, 325);
            this.guna2ImageButton5.Name = "guna2ImageButton5";
            this.guna2ImageButton5.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton5.PressedState.Parent = this.guna2ImageButton5;
            this.guna2ImageButton5.Size = new System.Drawing.Size(68, 73);
            this.guna2ImageButton5.TabIndex = 46;
            // 
            // Edificio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(97)))), ((int)(((byte)(141)))));
            this.ClientSize = new System.Drawing.Size(1096, 840);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.guna2ImageButton1);
            this.Controls.Add(this.BUSCUSER);
            this.Controls.Add(this.datos);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.guna2PictureBox3);
            this.Controls.Add(this.guna2Panel1);
            this.Name = "Edificio";
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.guna2Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label datos;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2TextBox txtcarpropietarios;
        private Guna.UI2.WinForms.Guna2TextBox txtmetro;
        private Guna.UI2.WinForms.Guna2TextBox txtcarfecha;
        private Guna.UI2.WinForms.Guna2TextBox txtcarcantidad;
        private Guna.UI2.WinForms.Guna2TextBox txtvalor2;
        private Guna.UI2.WinForms.Guna2TextBox txtvalor1;
        private Guna.UI2.WinForms.Guna2TextBox txtdeuda;
        private Guna.UI2.WinForms.Guna2TextBox txtubicacion;
        private Guna.UI2.WinForms.Guna2TextBox Txtcatastro;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
        private Guna.UI2.WinForms.Guna2TextBox titulo;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton1;
        private Guna.UI2.WinForms.Guna2TextBox BUSCUSER;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton4;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton2;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton5;
    }
}