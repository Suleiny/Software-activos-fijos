﻿
namespace Pruebaaa
{
    partial class Registro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registro));
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.User = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.Registr = new Guna.UI2.WinForms.Guna2Button();
            this.claveuser = new Guna.UI2.WinForms.Guna2TextBox();
            this.correouser = new Guna.UI2.WinForms.Guna2TextBox();
            this.usuarionombre = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2CustomGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.User)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.BorderRadius = 20;
            this.guna2CustomGradientPanel1.Controls.Add(this.User);
            this.guna2CustomGradientPanel1.Controls.Add(this.guna2PictureBox2);
            this.guna2CustomGradientPanel1.Controls.Add(this.guna2PictureBox1);
            this.guna2CustomGradientPanel1.Controls.Add(this.guna2PictureBox3);
            this.guna2CustomGradientPanel1.Controls.Add(this.Registr);
            this.guna2CustomGradientPanel1.Controls.Add(this.claveuser);
            this.guna2CustomGradientPanel1.Controls.Add(this.correouser);
            this.guna2CustomGradientPanel1.Controls.Add(this.usuarionombre);
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(238, 4);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.ShadowDecoration.Parent = this.guna2CustomGradientPanel1;
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(539, 571);
            this.guna2CustomGradientPanel1.TabIndex = 1;
            // 
            // User
            // 
            this.User.BackColor = System.Drawing.Color.Transparent;
            this.User.FillColor = System.Drawing.Color.Transparent;
            this.User.Image = ((System.Drawing.Image)(resources.GetObject("User.Image")));
            this.User.Location = new System.Drawing.Point(214, 21);
            this.User.Name = "User";
            this.User.ShadowDecoration.Parent = this.User;
            this.User.Size = new System.Drawing.Size(130, 139);
            this.User.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.User.TabIndex = 27;
            this.User.TabStop = false;
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox2.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox2.Image")));
            this.guna2PictureBox2.Location = new System.Drawing.Point(94, 379);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.ShadowDecoration.Parent = this.guna2PictureBox2;
            this.guna2PictureBox2.Size = new System.Drawing.Size(46, 51);
            this.guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox2.TabIndex = 26;
            this.guna2PictureBox2.TabStop = false;
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.Location = new System.Drawing.Point(94, 279);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(46, 51);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 25;
            this.guna2PictureBox1.TabStop = false;
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox3.Image")));
            this.guna2PictureBox3.Location = new System.Drawing.Point(94, 182);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(46, 51);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox3.TabIndex = 24;
            this.guna2PictureBox3.TabStop = false;
            // 
            // Registr
            // 
            this.Registr.BackColor = System.Drawing.Color.White;
            this.Registr.BorderColor = System.Drawing.Color.Transparent;
            this.Registr.BorderRadius = 8;
            this.Registr.CheckedState.Parent = this.Registr;
            this.Registr.CustomImages.Parent = this.Registr;
            this.Registr.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Registr.ForeColor = System.Drawing.Color.Black;
            this.Registr.HoverState.Parent = this.Registr;
            this.Registr.Location = new System.Drawing.Point(180, 467);
            this.Registr.Name = "Registr";
            this.Registr.ShadowDecoration.Parent = this.Registr;
            this.Registr.Size = new System.Drawing.Size(180, 45);
            this.Registr.TabIndex = 3;
            this.Registr.Text = "Registrar";
            this.Registr.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // claveuser
            // 
            this.claveuser.BorderRadius = 5;
            this.claveuser.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.claveuser.DefaultText = "";
            this.claveuser.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.claveuser.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.claveuser.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.claveuser.DisabledState.Parent = this.claveuser;
            this.claveuser.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.claveuser.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.claveuser.FocusedState.Parent = this.claveuser;
            this.claveuser.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.claveuser.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.claveuser.HoverState.Parent = this.claveuser;
            this.claveuser.Location = new System.Drawing.Point(146, 379);
            this.claveuser.Name = "claveuser";
            this.claveuser.PasswordChar = '\0';
            this.claveuser.PlaceholderText = "Contraseña";
            this.claveuser.SelectedText = "";
            this.claveuser.ShadowDecoration.Parent = this.claveuser;
            this.claveuser.Size = new System.Drawing.Size(302, 51);
            this.claveuser.TabIndex = 2;
            // 
            // correouser
            // 
            this.correouser.BorderRadius = 5;
            this.correouser.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.correouser.DefaultText = "";
            this.correouser.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.correouser.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.correouser.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.correouser.DisabledState.Parent = this.correouser;
            this.correouser.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.correouser.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.correouser.FocusedState.Parent = this.correouser;
            this.correouser.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.correouser.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.correouser.HoverState.Parent = this.correouser;
            this.correouser.Location = new System.Drawing.Point(146, 279);
            this.correouser.Name = "correouser";
            this.correouser.PasswordChar = '\0';
            this.correouser.PlaceholderText = "Correo";
            this.correouser.SelectedText = "";
            this.correouser.ShadowDecoration.Parent = this.correouser;
            this.correouser.Size = new System.Drawing.Size(302, 51);
            this.correouser.TabIndex = 1;
            // 
            // usuarionombre
            // 
            this.usuarionombre.BorderRadius = 5;
            this.usuarionombre.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.usuarionombre.DefaultText = "";
            this.usuarionombre.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.usuarionombre.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.usuarionombre.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.usuarionombre.DisabledState.Parent = this.usuarionombre;
            this.usuarionombre.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.usuarionombre.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.usuarionombre.FocusedState.Parent = this.usuarionombre;
            this.usuarionombre.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.usuarionombre.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.usuarionombre.HoverState.Parent = this.usuarionombre;
            this.usuarionombre.Location = new System.Drawing.Point(146, 182);
            this.usuarionombre.Name = "usuarionombre";
            this.usuarionombre.PasswordChar = '\0';
            this.usuarionombre.PlaceholderText = "Usuario";
            this.usuarionombre.SelectedText = "";
            this.usuarionombre.ShadowDecoration.Parent = this.usuarionombre;
            this.usuarionombre.Size = new System.Drawing.Size(302, 51);
            this.usuarionombre.TabIndex = 0;
            // 
            // Registro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(79)))), ((int)(((byte)(114)))));
            this.ClientSize = new System.Drawing.Size(1035, 587);
            this.Controls.Add(this.guna2CustomGradientPanel1);
            this.Name = "Registro";
            this.Text = "Registro";
            this.guna2CustomGradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.User)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2Button Registr;
        private Guna.UI2.WinForms.Guna2TextBox claveuser;
        private Guna.UI2.WinForms.Guna2TextBox correouser;
        private Guna.UI2.WinForms.Guna2TextBox usuarionombre;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2PictureBox User;
    }
}