﻿
namespace Pruebaaa
{
    partial class Maquinarias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Maquinarias));
            this.datos = new System.Windows.Forms.Label();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.mapropietarios = new Guna.UI2.WinForms.Guna2TextBox();
            this.mMarca = new Guna.UI2.WinForms.Guna2TextBox();
            this.mafecha = new Guna.UI2.WinForms.Guna2TextBox();
            this.macantidad = new Guna.UI2.WinForms.Guna2TextBox();
            this.valor2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.mavalor1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.mayeard = new Guna.UI2.WinForms.Guna2TextBox();
            this.mamodelo = new Guna.UI2.WinForms.Guna2TextBox();
            this.macodigo = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton4 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton2 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton1 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2CirclePictureBox7 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.labnombE = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.BUSCUSER = new Guna.UI2.WinForms.Guna2TextBox();
            this.btnpdf = new Guna.UI2.WinForms.Guna2Button();
            this.bucodigo = new Guna.UI2.WinForms.Guna2Button();
            this.bucmarca = new Guna.UI2.WinForms.Guna2Button();
            this.bumodelo = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // datos
            // 
            this.datos.AutoSize = true;
            this.datos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(79)))), ((int)(((byte)(114)))));
            this.datos.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.datos.ForeColor = System.Drawing.Color.Cornsilk;
            this.datos.Location = new System.Drawing.Point(2, 391);
            this.datos.Name = "datos";
            this.datos.Size = new System.Drawing.Size(204, 30);
            this.datos.TabIndex = 37;
            this.datos.Text = "Datos Registrados";
            this.datos.Click += new System.EventHandler(this.datos_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.Location = new System.Drawing.Point(1184, 537);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(228, 233);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 36;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.UseTransparentBackground = true;
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox3.Image")));
            this.guna2PictureBox3.Location = new System.Drawing.Point(310, 0);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(174, 171);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox3.TabIndex = 34;
            this.guna2PictureBox3.TabStop = false;
            this.guna2PictureBox3.Click += new System.EventHandler(this.guna2PictureBox3_Click);
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BorderColor = System.Drawing.Color.Black;
            this.guna2Panel1.BorderRadius = 20;
            this.guna2Panel1.Controls.Add(this.mapropietarios);
            this.guna2Panel1.Controls.Add(this.mMarca);
            this.guna2Panel1.Controls.Add(this.guna2ImageButton2);
            this.guna2Panel1.Controls.Add(this.guna2ImageButton4);
            this.guna2Panel1.Controls.Add(this.guna2ImageButton1);
            this.guna2Panel1.Controls.Add(this.guna2PictureBox3);
            this.guna2Panel1.Controls.Add(this.mafecha);
            this.guna2Panel1.Controls.Add(this.macantidad);
            this.guna2Panel1.Controls.Add(this.valor2);
            this.guna2Panel1.Controls.Add(this.mavalor1);
            this.guna2Panel1.Controls.Add(this.mayeard);
            this.guna2Panel1.Controls.Add(this.mamodelo);
            this.guna2Panel1.Controls.Add(this.macodigo);
            this.guna2Panel1.Location = new System.Drawing.Point(323, 12);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(808, 437);
            this.guna2Panel1.TabIndex = 33;
            // 
            // mapropietarios
            // 
            this.mapropietarios.BorderRadius = 5;
            this.mapropietarios.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mapropietarios.DefaultText = "";
            this.mapropietarios.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.mapropietarios.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.mapropietarios.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mapropietarios.DisabledState.Parent = this.mapropietarios;
            this.mapropietarios.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mapropietarios.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mapropietarios.FocusedState.Parent = this.mapropietarios;
            this.mapropietarios.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mapropietarios.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mapropietarios.HoverState.Parent = this.mapropietarios;
            this.mapropietarios.Location = new System.Drawing.Point(488, 231);
            this.mapropietarios.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.mapropietarios.Name = "mapropietarios";
            this.mapropietarios.PasswordChar = '\0';
            this.mapropietarios.PlaceholderForeColor = System.Drawing.Color.Black;
            this.mapropietarios.PlaceholderText = "Propietario";
            this.mapropietarios.SelectedText = "";
            this.mapropietarios.ShadowDecoration.Parent = this.mapropietarios;
            this.mapropietarios.Size = new System.Drawing.Size(256, 48);
            this.mapropietarios.TabIndex = 12;
            // 
            // mMarca
            // 
            this.mMarca.BorderRadius = 5;
            this.mMarca.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mMarca.DefaultText = "";
            this.mMarca.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.mMarca.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.mMarca.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mMarca.DisabledState.Parent = this.mMarca;
            this.mMarca.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mMarca.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mMarca.FocusedState.Parent = this.mMarca;
            this.mMarca.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mMarca.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mMarca.HoverState.Parent = this.mMarca;
            this.mMarca.Location = new System.Drawing.Point(12, 123);
            this.mMarca.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.mMarca.Name = "mMarca";
            this.mMarca.PasswordChar = '\0';
            this.mMarca.PlaceholderForeColor = System.Drawing.Color.Black;
            this.mMarca.PlaceholderText = "Marca";
            this.mMarca.SelectedText = "";
            this.mMarca.ShadowDecoration.Parent = this.mMarca;
            this.mMarca.Size = new System.Drawing.Size(256, 48);
            this.mMarca.TabIndex = 5;
            this.mMarca.TextChanged += new System.EventHandler(this.carMarca_TextChanged);
            // 
            // mafecha
            // 
            this.mafecha.BorderRadius = 5;
            this.mafecha.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mafecha.DefaultText = "";
            this.mafecha.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.mafecha.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.mafecha.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mafecha.DisabledState.Parent = this.mafecha;
            this.mafecha.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mafecha.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mafecha.FocusedState.Parent = this.mafecha;
            this.mafecha.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mafecha.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mafecha.HoverState.Parent = this.mafecha;
            this.mafecha.Location = new System.Drawing.Point(541, 299);
            this.mafecha.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.mafecha.Name = "mafecha";
            this.mafecha.PasswordChar = '\0';
            this.mafecha.PlaceholderForeColor = System.Drawing.Color.Black;
            this.mafecha.PlaceholderText = "Fecha de Ingreso";
            this.mafecha.SelectedText = "";
            this.mafecha.ShadowDecoration.Parent = this.mafecha;
            this.mafecha.Size = new System.Drawing.Size(256, 48);
            this.mafecha.TabIndex = 11;
            // 
            // macantidad
            // 
            this.macantidad.BorderRadius = 5;
            this.macantidad.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.macantidad.DefaultText = "";
            this.macantidad.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.macantidad.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.macantidad.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.macantidad.DisabledState.Parent = this.macantidad;
            this.macantidad.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.macantidad.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.macantidad.FocusedState.Parent = this.macantidad;
            this.macantidad.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.macantidad.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.macantidad.HoverState.Parent = this.macantidad;
            this.macantidad.Location = new System.Drawing.Point(46, 231);
            this.macantidad.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.macantidad.Name = "macantidad";
            this.macantidad.PasswordChar = '\0';
            this.macantidad.PlaceholderForeColor = System.Drawing.Color.Black;
            this.macantidad.PlaceholderText = "Cantidad";
            this.macantidad.SelectedText = "";
            this.macantidad.ShadowDecoration.Parent = this.macantidad;
            this.macantidad.Size = new System.Drawing.Size(255, 46);
            this.macantidad.TabIndex = 7;
            // 
            // valor2
            // 
            this.valor2.BorderRadius = 5;
            this.valor2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.valor2.DefaultText = "";
            this.valor2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.valor2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.valor2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.valor2.DisabledState.Parent = this.valor2;
            this.valor2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.valor2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.valor2.FocusedState.Parent = this.valor2;
            this.valor2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valor2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.valor2.HoverState.Parent = this.valor2;
            this.valor2.Location = new System.Drawing.Point(12, 299);
            this.valor2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.valor2.Name = "valor2";
            this.valor2.PasswordChar = '\0';
            this.valor2.PlaceholderForeColor = System.Drawing.Color.Black;
            this.valor2.PlaceholderText = "Precio Actual";
            this.valor2.SelectedText = "";
            this.valor2.ShadowDecoration.Parent = this.valor2;
            this.valor2.Size = new System.Drawing.Size(256, 48);
            this.valor2.TabIndex = 6;
            // 
            // mavalor1
            // 
            this.mavalor1.BorderRadius = 5;
            this.mavalor1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mavalor1.DefaultText = "";
            this.mavalor1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.mavalor1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.mavalor1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mavalor1.DisabledState.Parent = this.mavalor1;
            this.mavalor1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mavalor1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mavalor1.FocusedState.Parent = this.mavalor1;
            this.mavalor1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mavalor1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mavalor1.HoverState.Parent = this.mavalor1;
            this.mavalor1.Location = new System.Drawing.Point(542, 125);
            this.mavalor1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.mavalor1.Name = "mavalor1";
            this.mavalor1.PasswordChar = '\0';
            this.mavalor1.PlaceholderForeColor = System.Drawing.Color.Black;
            this.mavalor1.PlaceholderText = "Precio  Inicial";
            this.mavalor1.SelectedText = "";
            this.mavalor1.ShadowDecoration.Parent = this.mavalor1;
            this.mavalor1.Size = new System.Drawing.Size(255, 46);
            this.mavalor1.TabIndex = 4;
            // 
            // mayeard
            // 
            this.mayeard.BorderRadius = 5;
            this.mayeard.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mayeard.DefaultText = "";
            this.mayeard.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.mayeard.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.mayeard.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mayeard.DisabledState.Parent = this.mayeard;
            this.mayeard.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mayeard.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mayeard.FocusedState.Parent = this.mayeard;
            this.mayeard.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mayeard.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mayeard.HoverState.Parent = this.mayeard;
            this.mayeard.Location = new System.Drawing.Point(275, 177);
            this.mayeard.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.mayeard.Name = "mayeard";
            this.mayeard.PasswordChar = '\0';
            this.mayeard.PlaceholderForeColor = System.Drawing.Color.Black;
            this.mayeard.PlaceholderText = "Año";
            this.mayeard.SelectedText = "";
            this.mayeard.ShadowDecoration.Parent = this.mayeard;
            this.mayeard.Size = new System.Drawing.Size(256, 48);
            this.mayeard.TabIndex = 3;
            // 
            // mamodelo
            // 
            this.mamodelo.BorderRadius = 5;
            this.mamodelo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mamodelo.DefaultText = "";
            this.mamodelo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.mamodelo.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.mamodelo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mamodelo.DisabledState.Parent = this.mamodelo;
            this.mamodelo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mamodelo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mamodelo.FocusedState.Parent = this.mamodelo;
            this.mamodelo.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mamodelo.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mamodelo.HoverState.Parent = this.mamodelo;
            this.mamodelo.Location = new System.Drawing.Point(541, 46);
            this.mamodelo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.mamodelo.Name = "mamodelo";
            this.mamodelo.PasswordChar = '\0';
            this.mamodelo.PlaceholderForeColor = System.Drawing.Color.Black;
            this.mamodelo.PlaceholderText = "Modelo";
            this.mamodelo.SelectedText = "";
            this.mamodelo.ShadowDecoration.Parent = this.mamodelo;
            this.mamodelo.Size = new System.Drawing.Size(256, 48);
            this.mamodelo.TabIndex = 2;
            this.mamodelo.TextChanged += new System.EventHandler(this.carmodelo_TextChanged);
            // 
            // macodigo
            // 
            this.macodigo.BorderRadius = 5;
            this.macodigo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.macodigo.DefaultText = "";
            this.macodigo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.macodigo.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.macodigo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.macodigo.DisabledState.Parent = this.macodigo;
            this.macodigo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.macodigo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.macodigo.FocusedState.Parent = this.macodigo;
            this.macodigo.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.macodigo.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.macodigo.HoverState.Parent = this.macodigo;
            this.macodigo.Location = new System.Drawing.Point(12, 48);
            this.macodigo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.macodigo.Name = "macodigo";
            this.macodigo.PasswordChar = '\0';
            this.macodigo.PlaceholderForeColor = System.Drawing.Color.Black;
            this.macodigo.PlaceholderText = "Codigo";
            this.macodigo.SelectedText = "";
            this.macodigo.ShadowDecoration.Parent = this.macodigo;
            this.macodigo.Size = new System.Drawing.Size(255, 46);
            this.macodigo.TabIndex = 1;
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.CheckedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.Location = new System.Drawing.Point(7, 12);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.PressedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Size = new System.Drawing.Size(66, 65);
            this.guna2ImageButton3.TabIndex = 43;
            this.guna2ImageButton3.Click += new System.EventHandler(this.guna2ImageButton3_Click);
            // 
            // guna2ImageButton4
            // 
            this.guna2ImageButton4.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.CheckedState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.HoverState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton4.Image")));
            this.guna2ImageButton4.ImageRotate = 0F;
            this.guna2ImageButton4.Location = new System.Drawing.Point(155, 361);
            this.guna2ImageButton4.Name = "guna2ImageButton4";
            this.guna2ImageButton4.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.PressedState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.Size = new System.Drawing.Size(68, 73);
            this.guna2ImageButton4.TabIndex = 49;
            this.guna2ImageButton4.Click += new System.EventHandler(this.guna2ImageButton4_Click);
            // 
            // guna2ImageButton2
            // 
            this.guna2ImageButton2.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.CheckedState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.HoverState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton2.Image")));
            this.guna2ImageButton2.ImageRotate = 0F;
            this.guna2ImageButton2.Location = new System.Drawing.Point(574, 361);
            this.guna2ImageButton2.Name = "guna2ImageButton2";
            this.guna2ImageButton2.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.PressedState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.Size = new System.Drawing.Size(68, 73);
            this.guna2ImageButton2.TabIndex = 47;
            // 
            // guna2ImageButton1
            // 
            this.guna2ImageButton1.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.CheckedState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.HoverState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton1.Image")));
            this.guna2ImageButton1.ImageRotate = 0F;
            this.guna2ImageButton1.Location = new System.Drawing.Point(357, 361);
            this.guna2ImageButton1.Name = "guna2ImageButton1";
            this.guna2ImageButton1.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.PressedState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.Size = new System.Drawing.Size(68, 73);
            this.guna2ImageButton1.TabIndex = 48;
            this.guna2ImageButton1.Click += new System.EventHandler(this.guna2ImageButton1_Click);
            // 
            // guna2CirclePictureBox7
            // 
            this.guna2CirclePictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox7.Image")));
            this.guna2CirclePictureBox7.Location = new System.Drawing.Point(28, 68);
            this.guna2CirclePictureBox7.Name = "guna2CirclePictureBox7";
            this.guna2CirclePictureBox7.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox7.ShadowDecoration.Parent = this.guna2CirclePictureBox7;
            this.guna2CirclePictureBox7.Size = new System.Drawing.Size(178, 180);
            this.guna2CirclePictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox7.TabIndex = 47;
            this.guna2CirclePictureBox7.TabStop = false;
            // 
            // labnombE
            // 
            this.labnombE.AutoSize = true;
            this.labnombE.Font = new System.Drawing.Font("Times New Roman", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.labnombE.Location = new System.Drawing.Point(0, 265);
            this.labnombE.Name = "labnombE";
            this.labnombE.Size = new System.Drawing.Size(229, 39);
            this.labnombE.TabIndex = 46;
            this.labnombE.Text = "A & N Finanzas ";
            this.labnombE.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(7, 513);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(937, 287);
            this.dataGridView1.TabIndex = 48;
            // 
            // BUSCUSER
            // 
            this.BUSCUSER.BorderRadius = 5;
            this.BUSCUSER.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BUSCUSER.DefaultText = "";
            this.BUSCUSER.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BUSCUSER.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BUSCUSER.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BUSCUSER.DisabledState.Parent = this.BUSCUSER;
            this.BUSCUSER.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BUSCUSER.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BUSCUSER.FocusedState.Parent = this.BUSCUSER;
            this.BUSCUSER.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUSCUSER.ForeColor = System.Drawing.Color.Black;
            this.BUSCUSER.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BUSCUSER.HoverState.Parent = this.BUSCUSER;
            this.BUSCUSER.Location = new System.Drawing.Point(7, 461);
            this.BUSCUSER.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BUSCUSER.Name = "BUSCUSER";
            this.BUSCUSER.PasswordChar = '\0';
            this.BUSCUSER.PlaceholderText = "Ingresar Busquedad";
            this.BUSCUSER.SelectedText = "";
            this.BUSCUSER.ShadowDecoration.Parent = this.BUSCUSER;
            this.BUSCUSER.Size = new System.Drawing.Size(433, 46);
            this.BUSCUSER.TabIndex = 49;
            // 
            // btnpdf
            // 
            this.btnpdf.BorderRadius = 5;
            this.btnpdf.CheckedState.Parent = this.btnpdf;
            this.btnpdf.CustomImages.Parent = this.btnpdf;
            this.btnpdf.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(172)))), ((int)(((byte)(193)))));
            this.btnpdf.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnpdf.ForeColor = System.Drawing.Color.White;
            this.btnpdf.HoverState.Parent = this.btnpdf;
            this.btnpdf.Image = ((System.Drawing.Image)(resources.GetObject("btnpdf.Image")));
            this.btnpdf.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnpdf.ImageSize = new System.Drawing.Size(45, 45);
            this.btnpdf.Location = new System.Drawing.Point(959, 750);
            this.btnpdf.Name = "btnpdf";
            this.btnpdf.ShadowDecoration.Parent = this.btnpdf;
            this.btnpdf.Size = new System.Drawing.Size(207, 50);
            this.btnpdf.TabIndex = 50;
            this.btnpdf.Text = "Export PDF";
            // 
            // bucodigo
            // 
            this.bucodigo.BorderRadius = 5;
            this.bucodigo.CheckedState.Parent = this.bucodigo;
            this.bucodigo.CustomImages.Parent = this.bucodigo;
            this.bucodigo.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(172)))), ((int)(((byte)(193)))));
            this.bucodigo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bucodigo.ForeColor = System.Drawing.Color.White;
            this.bucodigo.HoverState.Parent = this.bucodigo;
            this.bucodigo.Image = ((System.Drawing.Image)(resources.GetObject("bucodigo.Image")));
            this.bucodigo.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bucodigo.ImageSize = new System.Drawing.Size(45, 45);
            this.bucodigo.Location = new System.Drawing.Point(959, 513);
            this.bucodigo.Name = "bucodigo";
            this.bucodigo.ShadowDecoration.Parent = this.bucodigo;
            this.bucodigo.Size = new System.Drawing.Size(207, 50);
            this.bucodigo.TabIndex = 53;
            this.bucodigo.Text = "Codigo";
            // 
            // bucmarca
            // 
            this.bucmarca.BorderRadius = 5;
            this.bucmarca.CheckedState.Parent = this.bucmarca;
            this.bucmarca.CustomImages.Parent = this.bucmarca;
            this.bucmarca.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(172)))), ((int)(((byte)(193)))));
            this.bucmarca.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bucmarca.ForeColor = System.Drawing.Color.White;
            this.bucmarca.HoverState.Parent = this.bucmarca;
            this.bucmarca.Image = ((System.Drawing.Image)(resources.GetObject("bucmarca.Image")));
            this.bucmarca.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bucmarca.ImageSize = new System.Drawing.Size(45, 45);
            this.bucmarca.Location = new System.Drawing.Point(959, 594);
            this.bucmarca.Name = "bucmarca";
            this.bucmarca.ShadowDecoration.Parent = this.bucmarca;
            this.bucmarca.Size = new System.Drawing.Size(207, 50);
            this.bucmarca.TabIndex = 54;
            this.bucmarca.Text = "Marca";
            // 
            // bumodelo
            // 
            this.bumodelo.BorderRadius = 5;
            this.bumodelo.CheckedState.Parent = this.bumodelo;
            this.bumodelo.CustomImages.Parent = this.bumodelo;
            this.bumodelo.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(172)))), ((int)(((byte)(193)))));
            this.bumodelo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bumodelo.ForeColor = System.Drawing.Color.White;
            this.bumodelo.HoverState.Parent = this.bumodelo;
            this.bumodelo.Image = ((System.Drawing.Image)(resources.GetObject("bumodelo.Image")));
            this.bumodelo.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bumodelo.ImageSize = new System.Drawing.Size(45, 45);
            this.bumodelo.Location = new System.Drawing.Point(959, 675);
            this.bumodelo.Name = "bumodelo";
            this.bumodelo.ShadowDecoration.Parent = this.bumodelo;
            this.bumodelo.Size = new System.Drawing.Size(207, 50);
            this.bumodelo.TabIndex = 55;
            this.bumodelo.Text = "Modelo";
            // 
            // Maquinarias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(137)))), ((int)(((byte)(123)))));
            this.ClientSize = new System.Drawing.Size(1458, 812);
            this.Controls.Add(this.bumodelo);
            this.Controls.Add(this.bucmarca);
            this.Controls.Add(this.bucodigo);
            this.Controls.Add(this.btnpdf);
            this.Controls.Add(this.BUSCUSER);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.guna2CirclePictureBox7);
            this.Controls.Add(this.labnombE);
            this.Controls.Add(this.guna2ImageButton3);
            this.Controls.Add(this.datos);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.guna2Panel1);
            this.Name = "Maquinarias";
            this.Load += new System.EventHandler(this.Maquinarias_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.guna2Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label datos;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2TextBox mapropietarios;
        private Guna.UI2.WinForms.Guna2TextBox mMarca;
        private Guna.UI2.WinForms.Guna2TextBox mafecha;
        private Guna.UI2.WinForms.Guna2TextBox macantidad;
        private Guna.UI2.WinForms.Guna2TextBox valor2;
        private Guna.UI2.WinForms.Guna2TextBox mavalor1;
        private Guna.UI2.WinForms.Guna2TextBox mayeard;
        private Guna.UI2.WinForms.Guna2TextBox mamodelo;
        private Guna.UI2.WinForms.Guna2TextBox macodigo;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton4;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton2;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox7;
        private System.Windows.Forms.Label labnombE;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Guna.UI2.WinForms.Guna2TextBox BUSCUSER;
        private Guna.UI2.WinForms.Guna2Button btnpdf;
        private Guna.UI2.WinForms.Guna2Button bucodigo;
        private Guna.UI2.WinForms.Guna2Button bucmarca;
        private Guna.UI2.WinForms.Guna2Button bumodelo;
    }
}