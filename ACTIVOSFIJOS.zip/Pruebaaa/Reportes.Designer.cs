﻿
namespace Pruebaaa
{
    partial class Reportes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Reportes));
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.User = new Guna.UI2.WinForms.Guna2PictureBox();
            this.telefono = new Guna.UI2.WinForms.Guna2TextBox();
            this.Asunto = new Guna.UI2.WinForms.Guna2TextBox();
            this.queja = new Guna.UI2.WinForms.Guna2Button();
            this.Resolucion = new Guna.UI2.WinForms.Guna2TextBox();
            this.correouser = new Guna.UI2.WinForms.Guna2TextBox();
            this.quejanombre = new Guna.UI2.WinForms.Guna2TextBox();
            this.quej = new System.Windows.Forms.Label();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2CustomGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.User)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.BorderRadius = 20;
            this.guna2CustomGradientPanel1.Controls.Add(this.User);
            this.guna2CustomGradientPanel1.Controls.Add(this.telefono);
            this.guna2CustomGradientPanel1.Controls.Add(this.Asunto);
            this.guna2CustomGradientPanel1.Controls.Add(this.queja);
            this.guna2CustomGradientPanel1.Controls.Add(this.Resolucion);
            this.guna2CustomGradientPanel1.Controls.Add(this.correouser);
            this.guna2CustomGradientPanel1.Controls.Add(this.quejanombre);
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(169, 99);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.ShadowDecoration.Parent = this.guna2CustomGradientPanel1;
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(737, 581);
            this.guna2CustomGradientPanel1.TabIndex = 3;
            this.guna2CustomGradientPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2CustomGradientPanel1_Paint);
            // 
            // User
            // 
            this.User.BackColor = System.Drawing.Color.Transparent;
            this.User.FillColor = System.Drawing.Color.Transparent;
            this.User.Image = ((System.Drawing.Image)(resources.GetObject("User.Image")));
            this.User.Location = new System.Drawing.Point(288, 3);
            this.User.Name = "User";
            this.User.ShadowDecoration.Parent = this.User;
            this.User.Size = new System.Drawing.Size(177, 161);
            this.User.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.User.TabIndex = 35;
            this.User.TabStop = false;
            this.User.Click += new System.EventHandler(this.User_Click);
            // 
            // telefono
            // 
            this.telefono.BorderRadius = 5;
            this.telefono.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.telefono.DefaultText = "";
            this.telefono.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.telefono.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.telefono.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.telefono.DisabledState.Parent = this.telefono;
            this.telefono.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.telefono.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.telefono.FocusedState.Parent = this.telefono;
            this.telefono.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.telefono.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.telefono.HoverState.Parent = this.telefono;
            this.telefono.Location = new System.Drawing.Point(59, 257);
            this.telefono.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.telefono.Name = "telefono";
            this.telefono.PasswordChar = '\0';
            this.telefono.PlaceholderForeColor = System.Drawing.Color.Black;
            this.telefono.PlaceholderText = "Telefono";
            this.telefono.SelectedText = "";
            this.telefono.ShadowDecoration.Parent = this.telefono;
            this.telefono.Size = new System.Drawing.Size(285, 51);
            this.telefono.TabIndex = 36;
            // 
            // Asunto
            // 
            this.Asunto.BorderRadius = 5;
            this.Asunto.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Asunto.DefaultText = "";
            this.Asunto.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Asunto.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Asunto.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Asunto.DisabledState.Parent = this.Asunto;
            this.Asunto.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Asunto.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Asunto.FocusedState.Parent = this.Asunto;
            this.Asunto.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold);
            this.Asunto.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Asunto.HoverState.Parent = this.Asunto;
            this.Asunto.Location = new System.Drawing.Point(399, 260);
            this.Asunto.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Asunto.Name = "Asunto";
            this.Asunto.PasswordChar = '\0';
            this.Asunto.PlaceholderForeColor = System.Drawing.Color.Black;
            this.Asunto.PlaceholderText = "Asunto";
            this.Asunto.SelectedText = "";
            this.Asunto.ShadowDecoration.Parent = this.Asunto;
            this.Asunto.Size = new System.Drawing.Size(301, 48);
            this.Asunto.TabIndex = 35;
            // 
            // queja
            // 
            this.queja.BackColor = System.Drawing.Color.White;
            this.queja.BorderColor = System.Drawing.Color.Transparent;
            this.queja.BorderRadius = 8;
            this.queja.CheckedState.Parent = this.queja;
            this.queja.CustomImages.Parent = this.queja;
            this.queja.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.queja.ForeColor = System.Drawing.Color.Black;
            this.queja.HoverState.Parent = this.queja;
            this.queja.Location = new System.Drawing.Point(297, 499);
            this.queja.Name = "queja";
            this.queja.ShadowDecoration.Parent = this.queja;
            this.queja.Size = new System.Drawing.Size(180, 45);
            this.queja.TabIndex = 31;
            this.queja.Text = "Reportar";
            this.queja.Click += new System.EventHandler(this.queja_Click);
            // 
            // Resolucion
            // 
            this.Resolucion.BorderRadius = 5;
            this.Resolucion.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Resolucion.DefaultText = "";
            this.Resolucion.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Resolucion.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Resolucion.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Resolucion.DisabledState.Parent = this.Resolucion;
            this.Resolucion.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Resolucion.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Resolucion.FocusedState.Parent = this.Resolucion;
            this.Resolucion.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Resolucion.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Resolucion.HoverState.Parent = this.Resolucion;
            this.Resolucion.Location = new System.Drawing.Point(166, 343);
            this.Resolucion.Name = "Resolucion";
            this.Resolucion.PasswordChar = '\0';
            this.Resolucion.PlaceholderForeColor = System.Drawing.Color.Black;
            this.Resolucion.PlaceholderText = "Resolucion";
            this.Resolucion.SelectedText = "";
            this.Resolucion.ShadowDecoration.Parent = this.Resolucion;
            this.Resolucion.Size = new System.Drawing.Size(431, 118);
            this.Resolucion.TabIndex = 30;
            this.Resolucion.TextChanged += new System.EventHandler(this.claveuser_TextChanged);
            // 
            // correouser
            // 
            this.correouser.BorderRadius = 5;
            this.correouser.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.correouser.DefaultText = "";
            this.correouser.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.correouser.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.correouser.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.correouser.DisabledState.Parent = this.correouser;
            this.correouser.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.correouser.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.correouser.FocusedState.Parent = this.correouser;
            this.correouser.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.correouser.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.correouser.HoverState.Parent = this.correouser;
            this.correouser.Location = new System.Drawing.Point(399, 173);
            this.correouser.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.correouser.Name = "correouser";
            this.correouser.PasswordChar = '\0';
            this.correouser.PlaceholderForeColor = System.Drawing.Color.Black;
            this.correouser.PlaceholderText = "Correo";
            this.correouser.SelectedText = "";
            this.correouser.ShadowDecoration.Parent = this.correouser;
            this.correouser.Size = new System.Drawing.Size(301, 48);
            this.correouser.TabIndex = 29;
            // 
            // quejanombre
            // 
            this.quejanombre.AcceptsReturn = true;
            this.quejanombre.BorderRadius = 5;
            this.quejanombre.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.quejanombre.DefaultText = "";
            this.quejanombre.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.quejanombre.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.quejanombre.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.quejanombre.DisabledState.Parent = this.quejanombre;
            this.quejanombre.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.quejanombre.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.quejanombre.FocusedState.Parent = this.quejanombre;
            this.quejanombre.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold);
            this.quejanombre.ForeColor = System.Drawing.Color.Black;
            this.quejanombre.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.quejanombre.HoverState.Parent = this.quejanombre;
            this.quejanombre.Location = new System.Drawing.Point(59, 173);
            this.quejanombre.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.quejanombre.Name = "quejanombre";
            this.quejanombre.PasswordChar = '\0';
            this.quejanombre.PlaceholderForeColor = System.Drawing.Color.Black;
            this.quejanombre.PlaceholderText = "Nombre";
            this.quejanombre.SelectedText = "";
            this.quejanombre.ShadowDecoration.Parent = this.quejanombre;
            this.quejanombre.Size = new System.Drawing.Size(285, 51);
            this.quejanombre.TabIndex = 28;
            this.quejanombre.TextChanged += new System.EventHandler(this.quejanombre_TextChanged);
            // 
            // quej
            // 
            this.quej.AutoSize = true;
            this.quej.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quej.Location = new System.Drawing.Point(391, 30);
            this.quej.Name = "quej";
            this.quej.Size = new System.Drawing.Size(320, 38);
            this.quej.TabIndex = 4;
            this.quej.Text = "!Genera tus Reportes!";
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.CheckedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.Location = new System.Drawing.Point(12, 12);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.PressedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Size = new System.Drawing.Size(66, 65);
            this.guna2ImageButton3.TabIndex = 43;
            this.guna2ImageButton3.Click += new System.EventHandler(this.guna2ImageButton3_Click);
            // 
            // Reportes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(179)))), ((int)(((byte)(157)))));
            this.ClientSize = new System.Drawing.Size(1035, 692);
            this.Controls.Add(this.guna2ImageButton3);
            this.Controls.Add(this.quej);
            this.Controls.Add(this.guna2CustomGradientPanel1);
            this.Name = "Reportes";
            this.Text = "Reportes";
            this.guna2CustomGradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.User)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2Button queja;
        private Guna.UI2.WinForms.Guna2TextBox Resolucion;
        private Guna.UI2.WinForms.Guna2TextBox correouser;
        private Guna.UI2.WinForms.Guna2TextBox quejanombre;
        private Guna.UI2.WinForms.Guna2PictureBox User;
        private Guna.UI2.WinForms.Guna2TextBox telefono;
        private Guna.UI2.WinForms.Guna2TextBox Asunto;
        private System.Windows.Forms.Label quej;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
    }
}